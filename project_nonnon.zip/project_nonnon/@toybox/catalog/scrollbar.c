




#include "../../nonnon/win32/win.c"
#include "../../nonnon/win32/win_scroll.c"

#include "../../nonnon/project/macro.c"




LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static HWND hgui[ 40 ];


	switch( msg ) {


	case WM_CREATE :


		// Window

		n_win_init_literal( hwnd, "Nonnon ScrollBar Catalog", "", "" );

		n_win_gui_literal( hwnd, HSCROLL, "", &hgui[ 0 ] );
		n_win_gui_literal( hwnd, HSCROLL, "", &hgui[ 1 ] );
		n_win_gui_literal( hwnd, HSCROLL, "", &hgui[ 2 ] );


		// Style

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );
		n_win_style_add( hwnd, WS_VSCROLL | WS_HSCROLL );

		//n_win_style_add( hwnd, SBS_SIZEBOX | SBS_SIZEBOXTOPLEFTALIGN );
		//n_win_style_add( hwnd, SBS_SIZEBOX | SBS_SIZEBOXBOTTOMRIGHTALIGN );


		//n_win_style_add( hgui[ 0 ], );
		//n_win_style_add( hgui[ 1 ], );
		n_win_style_add( hgui[ 2 ], SBS_SIZEGRIP );


		// Size

		{

		const n_bool redraw = n_true;


		s32 ctl,m;
		n_win_stdsize( hwnd, &ctl, NULL, &m );


		s32 csy = 256;
		s32 csx = 256;

		n_win_set( hwnd, NULL, csx + m, csy + m, N_WIN_SET_CENTERING );


		n_win_move( hgui[ 0 ], 0, ctl *  0, csx - ctl,ctl, redraw );
		n_win_move( hgui[ 1 ], 0, ctl *  1, csx - ctl,ctl, redraw );
		n_win_move( hgui[ 2 ], 0, ctl *  2, csx - ctl,ctl, redraw );

		}


		// Init

		n_win_scroll_init( hwnd, 2,1, 0,4, SB_VERT );
		n_win_scroll_init( hwnd, 2,1, 0,4, SB_HORZ );

		n_win_scroll_draw( hwnd, SB_VERT );
		n_win_scroll_draw( hwnd, SB_HORZ );


		n_win_scroll_init( hgui[ 0 ], 2,1, 0,4, SB_CTL );
		n_win_scroll_init( hgui[ 1 ], 2,1, 0,4, SB_CTL );
		n_win_scroll_init( hgui[ 2 ], 2,1, 0,4, SB_CTL );

		n_win_scroll_draw( hgui[ 0 ], SB_CTL );
		n_win_scroll_draw( hgui[ 1 ], SB_CTL );
		n_win_scroll_draw( hgui[ 2 ], SB_CTL );


//n_win_message_send( hgui[ 0 ], SBM_ENABLE_ARROWS, ESB_DISABLE_BOTH, 0 );


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_CTLCOLORSCROLLBAR :

		if ( (HWND) lparam == hgui[ 0 ] )
		{
			SetBkMode( (HDC) wparam, TRANSPARENT );
			SetTextColor( (HDC) wparam, RGB( 255,255,255 ) );

			return (LRESULT) GetStockObject( WHITE_BRUSH );
		}
		if ( (HWND) lparam == hgui[ 1 ] )
		{
			SetBkMode( (HDC) wparam, TRANSPARENT );
			SetTextColor( (HDC) wparam, RGB( 255,255,255 ) );

			return (LRESULT) GetStockObject( BLACK_BRUSH );
		}

	break;


	case WM_KEYDOWN :

		if ( wparam == VK_F1 )
		{
			EnableScrollBar( hwnd, SB_BOTH, ESB_DISABLE_BOTH );
		} else
		if ( wparam == VK_F2 )
		{
			EnableScrollBar( hwnd, SB_BOTH, ESB_ENABLE_BOTH );
		}// else

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

