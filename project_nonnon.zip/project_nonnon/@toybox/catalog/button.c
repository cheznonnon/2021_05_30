



#include "../../nonnon/win32/win.c"

#include "../../nonnon/project/macro.c"




LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static char *name_ico = "../../nonnon/project/neko.multi.ico";
	//const char *name_bmp = "./neko.bmp";


	static HWND hgui[ 40 ];

	static HICON   ico;
	static HBITMAP bmp;


	switch( msg ) {


	case WM_CREATE :


		// Window

		n_win_init( hwnd, "Nonnon Button Catalog", "", "" );


		n_win_gui( hwnd, BUTTON, "BS_TEXT / BS_PUSHBUTTON", &hgui[ 0] );
		n_win_gui( hwnd, BUTTON, "BS_DEFPUSHBUTTON",        &hgui[ 1] );
		n_win_gui( hwnd, BUTTON, "WM_CTLCOLORBTN",          &hgui[ 2] );
		n_win_gui( hwnd, BUTTON, "BS_CHECKBOX",             &hgui[ 3] );
		n_win_gui( hwnd, BUTTON, "BS_AUTOCHECKBOX",         &hgui[ 4] );
		n_win_gui( hwnd, BUTTON, "BS_RADIOBUTTON",          &hgui[ 5] );
		n_win_gui( hwnd, BUTTON, "BS_AUTORADIOBUTTON",      &hgui[ 6] );
		n_win_gui( hwnd, BUTTON, "BS_3STATE",               &hgui[ 7] );
		n_win_gui( hwnd, BUTTON, "BS_AUTO3STATE",           &hgui[ 8] );
		n_win_gui( hwnd, BUTTON, "BS_GROUPBOX",             &hgui[ 9] );
		n_win_gui( hwnd, BUTTON, "BS_PUSHLIKE",             &hgui[10] );

		n_win_gui( hwnd, BUTTON, "BS_TEXT / BS_PUSHBUTTON", &hgui[11] );
		n_win_gui( hwnd, BUTTON, "BS_DEFPUSHBUTTON",        &hgui[12] );
		n_win_gui( hwnd, BUTTON, "WM_CTLCOLORBTN",          &hgui[13] );
		n_win_gui( hwnd, BUTTON, "BS_CHECKBOX",             &hgui[14] );
		n_win_gui( hwnd, BUTTON, "BS_AUTOCHECKBOX",         &hgui[15] );
		n_win_gui( hwnd, BUTTON, "BS_RADIOBUTTON",          &hgui[16] );
		n_win_gui( hwnd, BUTTON, "BS_AUTORADIOBUTTON",      &hgui[17] );
		n_win_gui( hwnd, BUTTON, "BS_3STATE",               &hgui[18] );
		n_win_gui( hwnd, BUTTON, "BS_AUTO3STATE",           &hgui[19] );
		n_win_gui( hwnd, BUTTON, "BS_GROUPBOX",             &hgui[20] );
		n_win_gui( hwnd, BUTTON, "BS_PUSHLIKE",             &hgui[21] );

		n_win_gui( hwnd, BUTTON, "BS_LEFT",                 &hgui[22] );
		n_win_gui( hwnd, BUTTON, "BS_RIGHT",                &hgui[23] );
		n_win_gui( hwnd, BUTTON, "BS_TOP",                  &hgui[24] );
		n_win_gui( hwnd, BUTTON, "BS_BOTTOM",               &hgui[25] );

		n_win_gui( hwnd, BUTTON, "BS_ICON | BS_LEFT",       &hgui[26] );
		n_win_gui( hwnd, BUTTON, "BS_ICON | BS_RIGHT",      &hgui[27] );
		n_win_gui( hwnd, BUTTON, "BS_ICON | BS_TOP",        &hgui[28] );
		n_win_gui( hwnd, BUTTON, "BS_ICON | BS_BOTTOM",     &hgui[29] );

		n_win_gui( hwnd, BUTTON, "BS_LEFTTEXT/BS_RIGHTBUTTON", &hgui[30] );



		// Style

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		n_win_style_add( hgui[ 0], BS_TEXT );
		n_win_style_add( hgui[ 1], BS_DEFPUSHBUTTON );
		n_win_style_add( hgui[ 2], BS_TEXT );
		n_win_style_add( hgui[ 3], BS_CHECKBOX );
		n_win_style_add( hgui[ 4], BS_AUTOCHECKBOX );
		n_win_style_add( hgui[ 5], BS_RADIOBUTTON );
		n_win_style_add( hgui[ 6], BS_AUTORADIOBUTTON );
		n_win_style_add( hgui[ 7], BS_3STATE );
		n_win_style_add( hgui[ 8], BS_AUTO3STATE );
		n_win_style_add( hgui[ 9], BS_GROUPBOX );
		n_win_style_add( hgui[10], BS_AUTO3STATE | BS_PUSHLIKE );

		n_win_checkbox_add( hgui[  4 ] );
		n_win_checkbox_add( hgui[  6 ] );
		n_win_checkbox_set( hgui[  8 ], BST_INDETERMINATE );
		n_win_checkbox_set( hgui[ 10 ], BST_INDETERMINATE );


		n_win_style_add( hgui[11], BS_FLAT | BS_TEXT );
		n_win_style_add( hgui[12], BS_FLAT | BS_DEFPUSHBUTTON );
		n_win_style_add( hgui[13], BS_FLAT | BS_TEXT );
		n_win_style_add( hgui[14], BS_FLAT | BS_CHECKBOX );
		n_win_style_add( hgui[15], BS_FLAT | BS_AUTOCHECKBOX );
		n_win_style_add( hgui[16], BS_FLAT | BS_RADIOBUTTON );
		n_win_style_add( hgui[17], BS_FLAT | BS_AUTORADIOBUTTON );
		n_win_style_add( hgui[18], BS_FLAT | BS_3STATE );
		n_win_style_add( hgui[19], BS_FLAT | BS_AUTO3STATE );
		n_win_style_add( hgui[20], BS_FLAT | BS_GROUPBOX );
		n_win_style_add( hgui[21], BS_FLAT | BS_AUTO3STATE | BS_PUSHLIKE );

		n_win_checkbox_add( hgui[ 15 ] );
		n_win_checkbox_add( hgui[ 17 ] );
		n_win_checkbox_set( hgui[ 19 ], BST_INDETERMINATE );
		n_win_checkbox_set( hgui[ 21 ], BST_INDETERMINATE );


		n_win_style_add( hgui[22], BS_LEFT );
		n_win_style_add( hgui[23], BS_RIGHT );
		n_win_style_add( hgui[24], BS_TOP );
		n_win_style_add( hgui[25], BS_BOTTOM );

		n_win_style_add( hgui[26], BS_ICON | BS_LEFT );
		n_win_style_add( hgui[27], BS_ICON | BS_RIGHT );
		n_win_style_add( hgui[28], BS_ICON | BS_TOP );
		n_win_style_add( hgui[29], BS_ICON | BS_BOTTOM );

		n_win_style_add( hgui[30], BS_AUTOCHECKBOX | BS_LEFTTEXT );


		ico = n_win_icon_init( name_ico, 0, N_WIN_ICON_INIT_OPTION_DEFAULT );

		n_win_icon_set( hgui[26], ico );
		n_win_icon_set( hgui[27], ico );
		n_win_icon_set( hgui[28], ico );
		n_win_icon_set( hgui[29], ico );



		// Size

		{

		const n_bool redraw = n_true;


		s32 ctl,ico,m;
		n_win_stdsize( hwnd, &ctl, &ico, &m );


		s32 csy = ctl * 15;
		s32 csx = ico *  8;

		n_win_set( hwnd, NULL, csx + m, csy + m, N_WIN_SET_CENTERING );


		s32 half = ( csx - m ) / 2;
		s32 qrtr = ( csx - m ) / 4;


		s32 x = 0;
		s32 y = 0;

		n_win_move( hgui[ 0], x, y,  csx, ctl, redraw ); x += csx;  y += ctl; x = 0;
		n_win_move( hgui[ 1], x, y, half, ctl, redraw ); x += half;
		n_win_move( hgui[ 2], x, y, half, ctl, redraw ); x += csx;  y += ctl; x = 0;
		n_win_move( hgui[ 3], x, y, half, ctl, redraw ); x += half;
		n_win_move( hgui[ 4], x, y, half, ctl, redraw ); x += csx;  y += ctl; x = 0;
		n_win_move( hgui[ 5], x, y, half, ctl, redraw ); x += half;
		n_win_move( hgui[ 6], x, y, half, ctl, redraw ); x += csx;  y += ctl; x = 0;
		n_win_move( hgui[ 7], x, y, half, ctl, redraw ); x += half;
		n_win_move( hgui[ 8], x, y, half, ctl, redraw ); x += csx;  y += ctl; x = 0;
		n_win_move( hgui[ 9], x, y, half, ctl, redraw ); x += half;
		n_win_move( hgui[10], x, y, half, ctl, redraw ); x += csx;  y += ctl; x = 0;

		n_win_move( hgui[11], x, y,  csx, ctl, redraw ); x += csx;  y += ctl; x = 0;
		n_win_move( hgui[12], x, y, half, ctl, redraw ); x += half;
		n_win_move( hgui[13], x, y, half, ctl, redraw ); x += csx;  y += ctl; x = 0;
		n_win_move( hgui[14], x, y, half, ctl, redraw ); x += half;
		n_win_move( hgui[15], x, y, half, ctl, redraw ); x += csx;  y += ctl; x = 0;
		n_win_move( hgui[16], x, y, half, ctl, redraw ); x += half;
		n_win_move( hgui[17], x, y, half, ctl, redraw ); x += csx;  y += ctl; x = 0;
		n_win_move( hgui[18], x, y, half, ctl, redraw ); x += half;
		n_win_move( hgui[19], x, y, half, ctl, redraw ); x += csx;  y += ctl; x = 0;
		n_win_move( hgui[20], x, y, half, ctl, redraw ); x += half;
		n_win_move( hgui[21], x, y, half, ctl, redraw ); x += csx;  y += ctl; x = 0;

		n_win_move( hgui[22], x, y, qrtr, ctl, redraw ); x += qrtr;
		n_win_move( hgui[23], x, y, qrtr, ctl, redraw ); x += qrtr;
		n_win_move( hgui[24], x, y, qrtr, ctl, redraw ); x += qrtr;
		n_win_move( hgui[25], x, y, qrtr, ctl, redraw ); x += qrtr; y += ctl; x = 0;

		n_win_move( hgui[26], x, y, qrtr, ctl, redraw ); x += qrtr;
		n_win_move( hgui[27], x, y, qrtr, ctl, redraw ); x += qrtr;
		n_win_move( hgui[28], x, y, qrtr, ctl, redraw ); x += qrtr;
		n_win_move( hgui[29], x, y, qrtr, ctl, redraw ); x += qrtr; y += ctl; x = 0;

		n_win_move( hgui[30], x, y,  csx, ctl, redraw ); x += csx;  y += ctl; x = 0;

		}


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_CTLCOLORBTN :

		if ( ( (HWND) lparam == hgui[ 2] )||( (HWND) lparam == hgui[13] ) )
		{
			SetBkMode( (HDC) wparam, TRANSPARENT );
			SetTextColor( (HDC) wparam, RGB( 255,255,255 ) );

			return (LRESULT) GetStockObject( BLACK_BRUSH );
		}

	break;


	case WM_KEYDOWN :

		if ( wparam == VK_F1 )
		{

			SIZE size_1 = { 0,0 };
			SIZE size_2 = { 0,0 };


			HWND h = n_win_cursor2hwnd();


			n_posix_char str[ 100 ];

			HDC hdc = GetDC( h );
			GetWindowText( h, str, 100 - 1 );
			GetTextExtentPoint32( hdc, str, n_posix_strlen( str ), &size_1 );
			ReleaseDC( h, hdc );


			// BCM_FIRST        0x1600
			// BCM_GETIDEALSIZE (BCM_FIRST + 1)

			n_win_message_send( h, 0x1601, 0, &size_2 );


			n_posix_sprintf_literal
			(
				str,
				"%ld x %ld : %ld x %ld",
				size_1.cx, size_1.cy,
				size_2.cx, size_2.cy
			);

			n_project_dialog_info( hwnd, str );


			s32 x, y;
			n_win_position_relative( hwnd, h, &x, &y );

			n_win_move_simple( h, x, y, size_2.cx, size_2.cy, n_true );

		}

	break;


	case WM_COMMAND :

		if ( BN_CLICKED == HIWORD( wparam ) )
		{
			//MessageBoxA( hwnd, "", "", 0 );
		}

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_win_icon_exit( ico );
		n_win_bitmap_exit( bmp );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{

	// for loading icon

	n_win_exedir2curdir();


	return n_win_main( NULL, WndProc );
}

