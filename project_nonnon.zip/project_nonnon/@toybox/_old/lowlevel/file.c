// Nonnon Posix Compatibility Layer
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [!] : for future scalability with Unicode
//
//	a : unicows.dll doesn't wrap some posix functions
//	b : _wstat() will return error in Win9x




#ifndef _H_NONNON_NEUTRAL_FILE
#define _H_NONNON_NEUTRAL_FILE




#include "./posix.c"
#include "./type.c"




typedef struct {

	u8 *data;
	int byte;
	int seek;

} n_file;




// internal
int
n_file_error( const n_file *f )
{

	if ( f       == NULL ) { return 1; }
	if ( f->data == NULL ) { return 1; }
	if ( f->byte <     0 ) { return 1; }


	return 0;
}

void
n_file_zero( n_file *f )
{

	if ( f == NULL ) { return; }


	n_memory_zero( f, sizeof(n_file) );


	return;
}

void
n_file_free( n_file *f )
{

	if ( f == NULL ) { return; }


	free( f->data );

	n_file_zero( f );


	return;
}

void
n_file_new( n_file *f, int byte )
{

	if ( f == NULL ) { return; }


	n_file_free( f );


	if ( byte < 0 ) { byte = 0; }

	f->byte = byte;
	f->data = calloc( f->byte, 1 );


	return;
}

int
n_file_load( n_file *f, const char *name )
{

	if ( f == NULL ) { return 1; }


	FILE *fp;


	fp = n_posix_fopen_read( name );
	if ( fp == NULL ) { return 2; }

	f->byte = n_posix_stat_size( name );
	f->data = malloc( f->byte );

	fread( f->data, f->byte, 1, fp );

	fclose( fp );


	return 0;
}

#define n_file_save_literal( f, name ) n_file_save( f, n_posix_literal( name ) )

bool
n_file_save( n_file *f, const n_posix_char *name )
{

	if ( n_file_error( f ) ) { return 1; }


	FILE *fp;


	fp = n_posix_fopen_write( name );
	if ( fp == NULL ) { return true; }

	fwrite( f->data, f->byte, 1, fp );

	fclose( fp );


	return false;
}

void
n_file_get( n_file *f, u8 *data, int byte )
{

	if ( n_file_error( f ) ) { return; }
	if ( data == NULL ) { return; }


	if ( byte < 0 ) { byte = 0; }

	if ( ( f->seek + byte ) > f->byte ) { byte = f->byte - f->seek; }


	memcpy( data, &f->data[ f->seek ], byte );

	f->seek += byte;


	return;
}

void
n_file_set( n_file *f, const u8 *data, int byte )
{

	if ( n_file_error( f ) ) { return; }
	if ( data == NULL ) { return; }


	if ( byte < 0 ) { byte = 0; }

	if ( ( f->seek + byte ) > f->byte ) { byte = f->byte - f->seek; }


	memcpy( &f->data[ f->seek ], data, byte );

	f->seek += byte;


	return;
}

void
n_file_seek( n_file *f, int position )
{

	if ( n_file_error( f ) ) { return; }


	if ( position < 0 ) { position = 0; }

	f->seek = position;


	return;
}


#endif // _H_NONNON_NEUTRAL_FILE


/*


void
n_file_debug_iotest( const char *fname )
{

	n_file f, t;


	n_file_zero( &f );
	n_file_zero( &t );

	n_file_load( &f, fname  );
	n_file_new ( &t, f.byte );

	n_file_get( &f, t.data, t.byte );
	n_file_save( &t, "result_t_get", 1 );

	n_file_set( &t, f.data, f.byte );
	n_file_save( &t, "result_t_set", 1 );

	n_file_save( &f, "result_f", 1 );

	n_file_free( &f );
	n_file_free( &t );


	return;
}


*/

