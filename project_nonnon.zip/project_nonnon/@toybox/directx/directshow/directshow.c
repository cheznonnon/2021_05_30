// Nonnon DirectX
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../../../nonnon/com/com.c"
#include "../../../nonnon/win32/win.c"


#include "../../../nonnon/project/macro.c"




// [Patch]

#define IBaseFilter   void
#define IEnumFilters  void
#define IPin          void
#define OATRUE        ( -1 )
#define OAFALSE       (  0 )
#define OAFilterState long
#define OAEVENT       LONG_PTR
#define OAHWND        LONG_PTR
#define REFTIME       double




GUID CLSID_FilterGraph = { 0xe436ebb3, 0x524f, 0x11ce, { 0x9f, 0x53, 0x00, 0x20, 0xaf, 0x0b, 0xa7, 0x70 } };
GUID IID_IGraphBuilder = { 0x56a868a9, 0x0ad4, 0x11ce, { 0xb0, 0x3a, 0x00, 0x20, 0xaf, 0x0b, 0xa7, 0x70 } };
GUID IID_IMediaControl = { 0x56a868b1, 0x0ad4, 0x11ce, { 0xb0, 0x3a, 0x00, 0x20, 0xaf, 0x0b, 0xa7, 0x70 } };
GUID IID_IMediaEvent   = { 0x56a868b6, 0x0ad4, 0x11ce, { 0xb0, 0x3a, 0x00, 0x20, 0xaf, 0x0b, 0xa7, 0x70 } };


typedef struct _AMMediaType
{

	GUID       majortype;
	GUID       subtype;
	BOOL       bFixedSizeSamples;
	BOOL       bTemporalCompression;
	ULONG      lSampleSize;
	GUID      formattype;
	IUnknown *pUnk;
	ULONG     cbFormat;
	BYTE     *pbFormat;

} AM_MEDIA_TYPE;


#define INTERFACE IGraphBuilder
DECLARE_INTERFACE_( IGraphBuilder, IUnknown )
{
	STDMETHOD ( QueryInterface )( THIS_ REFIID, PVOID* ) PURE;
	STDMETHOD_( ULONG, AddRef  )( THIS ) PURE;
	STDMETHOD_( ULONG, Release )( THIS ) PURE;

	STDMETHOD( AddFilter               )( THIS_ IBaseFilter*, LPCWSTR ) PURE;
	STDMETHOD( RemoveFilter            )( THIS_ IBaseFilter* ) PURE;
	STDMETHOD( EnumFilters             )( THIS_ IEnumFilters** ) PURE;
	STDMETHOD( FindFilterByName        )( THIS_ LPCWSTR, IBaseFilter** ) PURE;
	STDMETHOD( ConnectDirect           )( THIS_ IPin*, IPin*, const AM_MEDIA_TYPE* ) PURE;
	STDMETHOD( Reconnect               )( THIS_ IPin* ) PURE;
	STDMETHOD( Disconnect              )( THIS_ IPin* ) PURE;
	STDMETHOD( SetDefaultSyncSource    )( THIS ) PURE;

	STDMETHOD( Connect                 )( THIS_ IPin*, IPin* ) PURE;
	STDMETHOD( Render                  )( THIS ) PURE;
	STDMETHOD( RenderFile              )( THIS_ LPCWSTR, LPCWSTR ) PURE;
	STDMETHOD( AddSourceFilter         )( THIS_ LPCWSTR, LPCWSTR, IBaseFilter** ) PURE;
	STDMETHOD( SetLogFile              )( THIS_ DWORD_PTR ) PURE;
	STDMETHOD( Abort                   )( THIS ) PURE;
	STDMETHOD( ShouldOperationContinue )( THIS ) PURE;
};
#undef INTERFACE

#define IGraphBuilder_QueryInterface(          p, a,b   ) (p)->lpVtbl->QueryInterface(          p, a,b   )
#define IGraphBuilder_AddRef(                  p        ) (p)->lpVtbl->AddRef(                  p        )
#define IGraphBuilder_Release(                 p        ) (p)->lpVtbl->Release(                 p        )

#define IGraphBuilder_AddFilter(               p, a,b   ) (p)->lpVtbl->AddFilter(               p, a,b   )
#define IGraphBuilder_RemoveFilter(            p, a     ) (p)->lpVtbl->RemoveFilter(            p, a     )
#define IGraphBuilder_EnumFilters(             p, a     ) (p)->lpVtbl->EnumFilters(             p, a     )
#define IGraphBuilder_FindFilterByName(        p, a,b   ) (p)->lpVtbl->FindFilterByName(        p, a,b   )
#define IGraphBuilder_ConnectDirect(           p, a,b,c ) (p)->lpVtbl->ConnectDirect(           p, a,b,c )
#define IGraphBuilder_Reconnect(               p, a     ) (p)->lpVtbl->Reconnect(               p, a     )
#define IGraphBuilder_Disconnect(              p, a     ) (p)->lpVtbl->Disconnect(              p, a     )
#define IGraphBuilder_SetDefaultSyncSource(    p, a     ) (p)->lpVtbl->SetDefaultSyncSource(    p, a     )

#define IGraphBuilder_Connect(                 p, a,b   ) (p)->lpVtbl->Connect(                 p, a,b   )
#define IGraphBuilder_Render(                  p        ) (p)->lpVtbl->Render(                  p        )
#define IGraphBuilder_RenderFile(              p, a,b   ) (p)->lpVtbl->RenderFile(              p, a,b   )
#define IGraphBuilder_AddSourceFilter(         p, a,b,c ) (p)->lpVtbl->AddSourceFilter(         p, a,b,c )
#define IGraphBuilder_SetLogFile(              p, a     ) (p)->lpVtbl->SetLogFile(              p, a     )
#define IGraphBuilder_Abort(                   p        ) (p)->lpVtbl->Abort(                   p        )
#define IGraphBuilder_ShouldOperationContinue( p        ) (p)->lpVtbl->ShouldOperationContinue( p        )


#define INTERFACE IMediaControl
DECLARE_INTERFACE_( IMediaControl, IDispatch )
{
	STDMETHOD ( QueryInterface   )( THIS_ REFIID, PVOID* ) PURE;
	STDMETHOD_( ULONG, AddRef    )( THIS ) PURE;
	STDMETHOD_( ULONG, Release   )( THIS ) PURE;
	STDMETHOD ( GetTypeInfoCount )( THIS_ UINT* ) PURE;
	STDMETHOD ( GetTypeInfo      )( THIS_ UINT, LCID, LPTYPEINFO* ) PURE;
	STDMETHOD ( GetIDsOfNames    )( THIS_ REFIID, LPOLESTR*, UINT, LCID, DISPID* ) PURE;
	STDMETHOD ( Invoke           )( THIS_ DISPID, REFIID, LCID, WORD, DISPPARAMS*, VARIANT*, EXCEPINFO*, UINT* ) PURE;

	STDMETHOD( Run                     )( THIS ) PURE;
	STDMETHOD( Pause                   )( THIS ) PURE;
	STDMETHOD( Stop                    )( THIS ) PURE;
	STDMETHOD( GetState                )( THIS_ LONG, OAFilterState* ) PURE;
	STDMETHOD( RenderFile              )( THIS_ BSTR ) PURE;
	STDMETHOD( AddSourceFilter         )( THIS_ BSTR, IDispatch** ) PURE;
	STDMETHOD( get_FilterCollection    )( THIS_ IDispatch** ) PURE;
	STDMETHOD( get_RegFilterCollection )( THIS_ IDispatch** ) PURE;
	STDMETHOD( StopWhenReady           )( THIS ) PURE;
};
#undef INTERFACE

#define IMediaControl_QueryInterface(          p, a,b             ) (p)->lpVtbl->QueryInterface(          p, a,b             )
#define IMediaControl_AddRef(                  p                  ) (p)->lpVtbl->AddRef(                  p                  )
#define IMediaControl_Release(                 p                  ) (p)->lpVtbl->Release(                 p                  )
#define IMediaControl_GetTypeInfoCount(        p, a               ) (p)->lpVtbl->GetTypeInfoCount(        p, a               )
#define IMediaControl_GetTypeInfo(             p, a,b,c           ) (p)->lpVtbl->GetTypeInfo(             p, a,b,c           )
#define IMediaControl_GetIDsOfNames(           p, a,b,c,d,e       ) (p)->lpVtbl->GetIDsOfNames(           p, a,b,c,d,e       )
#define IMediaControl_Invoke(                  p, a,b,c,d,e,f,g,h ) (p)->lpVtbl->Invoke(                  p, a,b,c,d,e,f,g,h )

#define IMediaControl_Run(                     p                  ) (p)->lpVtbl->Run(                     p                  )
#define IMediaControl_Pause(                   p                  ) (p)->lpVtbl->Pause(                   p                  )
#define IMediaControl_Stop(                    p                  ) (p)->lpVtbl->Stop(                    p                  )
#define IMediaControl_GetState(                p, a,b             ) (p)->lpVtbl->GetState(                p, a,b             )
#define IMediaControl_RenderFile(              p, a               ) (p)->lpVtbl->RenderFile(              p, a               )
#define IMediaControl_AddSourceFilter(         p, a,b             ) (p)->lpVtbl->AddSourceFilter(         p, a,b             )
#define IMediaControl_get_FilterCollection(    p, a               ) (p)->lpVtbl->get_FilterCollection(    p, a               )
#define IMediaControl_get_RegFilterCollection( p, a               ) (p)->lpVtbl->get_RegFilterCollection( p, a               )
#define IMediaControl_StopWhenReady(           p                  ) (p)->lpVtbl->StopWhenReady(           p                  )


#define INTERFACE IMediaEvent
DECLARE_INTERFACE_( IMediaEvent, IDispatch )
{
	STDMETHOD ( QueryInterface   )( THIS_ REFIID, PVOID* ) PURE;
	STDMETHOD_( ULONG, AddRef    )( THIS ) PURE;
	STDMETHOD_( ULONG, Release   )( THIS ) PURE;
	STDMETHOD ( GetTypeInfoCount )( THIS_ UINT* ) PURE;
	STDMETHOD ( GetTypeInfo      )( THIS_ UINT, LCID, LPTYPEINFO* ) PURE;
	STDMETHOD ( GetIDsOfNames    )( THIS_ REFIID, LPOLESTR*, UINT, LCID, DISPID* ) PURE;
	STDMETHOD ( Invoke           )( THIS_ DISPID, REFIID, LCID, WORD, DISPPARAMS*, VARIANT*, EXCEPINFO*, UINT* ) PURE;

	STDMETHOD( GetEventHandle         )( THIS_ OAEVENT* ) PURE;
	STDMETHOD( GetEvent               )( THIS_ long*, LONG_PTR*, LONG_PTR*, long ) PURE;
	STDMETHOD( WaitForCompletion      )( THIS_ long, long* ) PURE;
	STDMETHOD( CancelDefaultHandling  )( THIS_ long ) PURE;
	STDMETHOD( RestoreDefaultHandling )( THIS_ long ) PURE;
	STDMETHOD( FreeEventParams        )( THIS_ long, LONG_PTR, LONG_PTR ) PURE;
};
#undef INTERFACE

#define IMediaEvent_QueryInterface(          p, a,b             ) (p)->lpVtbl->QueryInterface(          p, a,b             )
#define IMediaEvent_AddRef(                  p                  ) (p)->lpVtbl->AddRef(                  p                  )
#define IMediaEvent_Release(                 p                  ) (p)->lpVtbl->Release(                 p                  )
#define IMediaEvent_GetTypeInfoCount(        p, a               ) (p)->lpVtbl->GetTypeInfoCount(        p, a               )
#define IMediaEvent_GetTypeInfo(             p, a,b,c           ) (p)->lpVtbl->GetTypeInfo(             p, a,b,c           )
#define IMediaEvent_GetIDsOfNames(           p, a,b,c,d,e       ) (p)->lpVtbl->GetIDsOfNames(           p, a,b,c,d,e       )
#define IMediaEvent_Invoke(                  p, a,b,c,d,e,f,g,h ) (p)->lpVtbl->Invoke(                  p, a,b,c,d,e,f,g,h )

#define IMediaEvent_GetEventHandle(          p, a               ) (p)->lpVtbl->GetEventHandle(          p, a               )
#define IMediaEvent_GetEvent(                p, a,b,c,d         ) (p)->lpVtbl->GetEvent(                p, a,b,c,d         )
#define IMediaEvent_WaitForCompletion(       p, a,b             ) (p)->lpVtbl->WaitForCompletion(       p, a,b             )
#define IMediaEvent_CancelDefaultHandling(   p                  ) (p)->lpVtbl->CancelDefaultHandling(   p                  )
#define IMediaEvent_RestoreDefaultHandling(  p                  ) (p)->lpVtbl->RestoreDefaultHandling(  p                  )
#define IMediaEvent_FreeEventParams(         p, a,b,c           ) (p)->lpVtbl->FreeEventParams(         p, a,b,c           )




#ifndef __control_h__


const GUID IID_IVideoWindow = { 0x56a868b4, 0x0ad4,0x11ce, { 0xb0, 0x3a, 0x00, 0x20, 0xaf, 0x0b, 0xa7, 0x70 } };

#define INTERFACE IVideoWindow
DECLARE_INTERFACE_( IVideoWindow, IDispatch )
{
	STDMETHOD ( QueryInterface   )( THIS_ REFIID, PVOID* ) PURE;
	STDMETHOD_( ULONG, AddRef    )( THIS ) PURE;
	STDMETHOD_( ULONG, Release   )( THIS ) PURE;
	STDMETHOD ( GetTypeInfoCount )( THIS_ UINT* ) PURE;
	STDMETHOD ( GetTypeInfo      )( THIS_ UINT, LCID, LPTYPEINFO* ) PURE;
	STDMETHOD ( GetIDsOfNames    )( THIS_ REFIID, LPOLESTR*, UINT, LCID, DISPID* ) PURE;
	STDMETHOD ( Invoke           )( THIS_ DISPID, REFIID, LCID, WORD, DISPPARAMS*, VARIANT*, EXCEPINFO*, UINT* ) PURE;

	STDMETHOD( put_Caption           )( THIS_ BSTR  ) PURE;
	STDMETHOD( get_Caption           )( THIS_ BSTR* ) PURE;
	STDMETHOD( put_WindowStyle       )( THIS_ long  ) PURE;
	STDMETHOD( get_WindowStyle       )( THIS_ long* ) PURE;
	STDMETHOD( put_WindowStyleEx     )( THIS_ long  ) PURE;
	STDMETHOD( get_WindowStyleEx     )( THIS_ long* ) PURE;
	STDMETHOD( put_AutoShow          )( THIS_ long  ) PURE;
	STDMETHOD( get_AutoShow          )( THIS_ long* ) PURE;
	STDMETHOD( put_WindowState       )( THIS_ long  ) PURE;
	STDMETHOD( get_WindowState       )( THIS_ long* ) PURE;
	STDMETHOD( put_BackgroundPalette )( THIS_ long  ) PURE;
	STDMETHOD( get_BackgroundPalette )( THIS_ long* ) PURE;
	STDMETHOD( put_Visible           )( THIS_ long  ) PURE;
	STDMETHOD( get_Visible           )( THIS_ long* ) PURE;
	STDMETHOD( put_Left              )( THIS_ long  ) PURE;
	STDMETHOD( get_Left              )( THIS_ long* ) PURE;
	STDMETHOD( put_Width             )( THIS_ long  ) PURE;
	STDMETHOD( get_Width             )( THIS_ long* ) PURE;
	STDMETHOD( put_Top               )( THIS_ long  ) PURE;
	STDMETHOD( get_Top               )( THIS_ long* ) PURE;
	STDMETHOD( put_Height            )( THIS_ long  ) PURE;
	STDMETHOD( get_Height            )( THIS_ long* ) PURE;
	STDMETHOD( put_Owner             )( THIS_ OAHWND  ) PURE;
	STDMETHOD( get_Owner             )( THIS_ OAHWND* ) PURE;
	STDMETHOD( put_MessageDrain      )( THIS_ OAHWND  ) PURE;
	STDMETHOD( get_MessageDrain      )( THIS_ OAHWND* ) PURE;
	STDMETHOD( get_BorderColor       )( THIS_ long* ) PURE;
	STDMETHOD( put_BorderColor       )( THIS_ long  ) PURE;
	STDMETHOD( get_FullScreenMode    )( THIS_ long* ) PURE;
	STDMETHOD( put_FullScreenMode    )( THIS_ long  ) PURE;
	STDMETHOD( SetWindowForeground   )( THIS_ long  ) PURE;
	STDMETHOD( NotifyOwnerMessage    )( THIS_ OAHWND, long, LONG_PTR, LONG_PTR ) PURE;
	STDMETHOD( SetWindowPosition     )( THIS_ long, long, long, long ) PURE;
	STDMETHOD( GetWindowPosition     )( THIS_ long*, long*, long*, long* ) PURE;
	STDMETHOD( GetMinIdealImageSize  )( THIS_ long*, long* ) PURE;
	STDMETHOD( GetMaxIdealImageSize  )( THIS_ long*, long* ) PURE;
	STDMETHOD( GetRestorePosition    )( THIS_ long*, long*, long*, long* ) PURE;
	STDMETHOD( HideCursor            )( THIS_ long  ) PURE;
	STDMETHOD( IsCursorHidden        )( THIS_ long* ) PURE;
};
#undef INTERFACE

#define IVideoWindow_QueryInterface(        p, a,b             ) (p)->lpVtbl->QueryInterface(        p, a,b             )
#define IVideoWindow_AddRef(                p                  ) (p)->lpVtbl->AddRef(                p                  )
#define IVideoWindow_Release(               p                  ) (p)->lpVtbl->Release(               p                  )
#define IVideoWindow_GetTypeInfoCount(      p, a               ) (p)->lpVtbl->GetTypeInfoCount(      p, a               )
#define IVideoWindow_GetTypeInfo(           p, a,b,c           ) (p)->lpVtbl->GetTypeInfo(           p, a,b,c           )
#define IVideoWindow_GetIDsOfNames(         p, a,b,c,d,e       ) (p)->lpVtbl->GetIDsOfNames(         p, a,b,c,d,e       )
#define IVideoWindow_Invoke(                p, a,b,c,d,e,f,g,h ) (p)->lpVtbl->Invoke(                p, a,b,c,d,e,f,g,h )

#define IVideoWindow_put_Caption(           p, a               ) (p)->lpVtbl->put_Caption(           p, a               )
#define IVideoWindow_get_Caption(           p, a               ) (p)->lpVtbl->get_Caption(           p, a               )
#define IVideoWindow_put_WindowStyle(       p, a               ) (p)->lpVtbl->put_WindowStyle(       p, a               )
#define IVideoWindow_get_WindowStyle(       p, a               ) (p)->lpVtbl->get_WindowStyle(       p, a               )
#define IVideoWindow_put_WindowStyleEx(     p, a               ) (p)->lpVtbl->put_WindowStyleEx(     p, a               )
#define IVideoWindow_get_WindowStyleEx(     p, a               ) (p)->lpVtbl->get_WindowStyleEx(     p, a               )
#define IVideoWindow_put_AutoShow(          p, a               ) (p)->lpVtbl->put_AutoShow(          p, a               )
#define IVideoWindow_get_AutoShow(          p, a               ) (p)->lpVtbl->get_AutoShow(          p, a               )
#define IVideoWindow_put_WindowState(       p, a               ) (p)->lpVtbl->put_WindowState(       p, a               )
#define IVideoWindow_get_WindowState(       p, a               ) (p)->lpVtbl->get_WindowState(       p, a               )
#define IVideoWindow_put_BackgroundPalette( p, a               ) (p)->lpVtbl->put_BackgroundPalette( p, a               )
#define IVideoWindow_get_BackgroundPalette( p, a               ) (p)->lpVtbl->get_BackgroundPalette( p, a               )
#define IVideoWindow_put_Visible(           p, a               ) (p)->lpVtbl->put_Visible(           p, a               )
#define IVideoWindow_get_Visible(           p, a               ) (p)->lpVtbl->get_Visible(           p, a               )
#define IVideoWindow_put_Left(              p, a               ) (p)->lpVtbl->put_Left(              p, a               )
#define IVideoWindow_get_Left(              p, a               ) (p)->lpVtbl->get_Left(              p, a               )
#define IVideoWindow_put_Width(             p, a               ) (p)->lpVtbl->put_Width(             p, a               )
#define IVideoWindow_get_Width(             p, a               ) (p)->lpVtbl->get_Width(             p, a               )
#define IVideoWindow_put_Top(               p, a               ) (p)->lpVtbl->put_Top(               p, a               )
#define IVideoWindow_get_Top(               p, a               ) (p)->lpVtbl->get_Top(               p, a               )
#define IVideoWindow_put_Height(            p, a               ) (p)->lpVtbl->put_Height(            p, a               )
#define IVideoWindow_get_Height(            p, a               ) (p)->lpVtbl->get_Height(            p, a               )
#define IVideoWindow_put_Owner(             p, a               ) (p)->lpVtbl->put_Owner(             p, a               )
#define IVideoWindow_get_Owner(             p, a               ) (p)->lpVtbl->get_Owner(             p, a               )
//
#define IVideoWindow_SetWindowPosition(     p, a,b,c,d         ) (p)->lpVtbl->SetWindowPosition(     p, a,b,c,d         )
#define IVideoWindow_GetWindowPosition(     p, a,b,c,d         ) (p)->lpVtbl->GetWindowPosition(     p, a,b,c,d         )
#define IVideoWindow_GetMinIdealImageSize(  p, a,b             ) (p)->lpVtbl->GetMinIdealImageSize(  p, a,b             )
#define IVideoWindow_GetMaxIdealImageSize(  p, a,b             ) (p)->lpVtbl->GetMaxIdealImageSize(  p, a,b             )
#define IVideoWindow_GetRestorePosition(    p, a,b,c,d         ) (p)->lpVtbl->GetRestorePosition(    p, a,b,c,d         )
#define IVideoWindow_HideCursor(            p, a               ) (p)->lpVtbl->HideCursor(            p, a               )
#define IVideoWindow_IsCursorHidden(        p, a               ) (p)->lpVtbl->IsCursorHidden(        p, a               )

#endif // #ifndef __control_h__




typedef struct {

	IGraphBuilder *IGraphBuilder;
	IMediaControl *IMediaControl;
	IMediaEvent   *IMediaEvent;
	IVideoWindow  *IVideoWindow;

} n_directshow;




#define n_directshow_zero( p ) n_memory_zero( p, sizeof( n_directshow ) )




bool
n_directshow_exit( n_directshow *p )
{

	if ( p->IMediaControl )
	{
		IMediaControl_Stop( p->IMediaControl );
	}


	if ( p->IGraphBuilder ) { IGraphBuilder_Release( p->IGraphBuilder ); }
	if ( p->IMediaControl ) { IMediaControl_Release( p->IMediaControl ); }
	if ( p->IMediaEvent   ) {   IMediaEvent_Release( p->IMediaEvent   ); }
	if ( p->IVideoWindow  ) {  IVideoWindow_Release( p->IVideoWindow  ); }

	n_directshow_zero( p );


	CoUninitialize();


	return false;
}

bool
n_directshow_init( n_directshow *p, HWND hwnd )
{

	CoInitializeEx( NULL, 0 );


	CoCreateInstance
	(
		&CLSID_FilterGraph,
		NULL, 
		CLSCTX_ALL,
		&IID_IGraphBuilder,
		(void*) &p->IGraphBuilder
	);
	if ( p->IGraphBuilder == NULL )
	{
n_posix_debug_literal( " CoCreateInstance() " );

		n_directshow_exit( p );

		return true;
	}


	IGraphBuilder_QueryInterface( p->IGraphBuilder, &IID_IMediaControl, (void*) &p->IMediaControl );
	IGraphBuilder_QueryInterface( p->IGraphBuilder, &IID_IMediaEvent,   (void*) &p->IMediaEvent   );
	IGraphBuilder_QueryInterface( p->IGraphBuilder, &IID_IVideoWindow,  (void*) &p->IVideoWindow  );

	if (
		( p->IMediaControl == NULL )
		||
		( p->IMediaEvent   == NULL )
		||
		( p->IVideoWindow  == NULL )
	)
	if ( p->IGraphBuilder == NULL )
	{
n_posix_debug_literal( " IGraphBuilder_QueryInterface() " );

		n_directshow_exit( p );

		return true;
	}


	return false;
}

bool
n_directshow_play( n_directshow *p, HWND hwnd, const n_posix_char *name, bool wait )
{

	// [Needed] : after the second file

	IMediaControl_Stop( p->IMediaControl );


	// [!] : as same as IGraphBuilder_RenderFile( p, bstr, NULL )

	BSTR bstr = n_com_bstr_init( name );

	IMediaControl_RenderFile( p->IMediaControl, bstr );

	n_com_bstr_exit( bstr );


	// [Needed] : after RenderFile()

	IVideoWindow_put_Owner( p->IVideoWindow, (OAHWND) hwnd );
	IVideoWindow_put_WindowStyle( p->IVideoWindow, WS_CHILD | WS_CLIPSIBLINGS );

	s32 sx,sy; n_win_size_client( hwnd, &sx, &sy );

	//long sx,sy;
	//IVideoWindow_GetMinIdealImageSize( p->IVideoWindow, &sx, &sy );
	IVideoWindow_SetWindowPosition( p->IVideoWindow, 0,0,sx,sy );

	IVideoWindow_put_Visible( p->IVideoWindow, OATRUE );


	// Done!

	IMediaControl_Run( p->IMediaControl );

	if ( wait )
	{
		long eventcode = 0;
		IMediaEvent_WaitForCompletion( p->IMediaEvent, INFINITE, &eventcode );
	}


	return false;
}




LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_posix_char cmdline[ N_PATH_MAX ];
	static n_directshow d;


	switch( msg ) {


	case WM_CREATE :


		// Global

		n_win_exedir2curdir();
		n_win_commandline( cmdline );


		// Window

		n_win_init_literal( hwnd, "Nonnon DirectShow Test", "", "" );
		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );

		n_win_set( hwnd, NULL, 200,200, N_WIN_SET_CENTERING );


		// Display

		ShowWindow( hwnd, SW_NORMAL );

		n_directshow_zero( &d );
		n_directshow_init( &d, hwnd );

	break;


	case WM_DROPFILES :

		n_win_dropfiles( hwnd, wparam, cmdline );

		n_directshow_play( &d, hwnd, cmdline, false );

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_directshow_exit( &d );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

