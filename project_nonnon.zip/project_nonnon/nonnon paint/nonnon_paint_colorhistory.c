// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_progressbar.c"

#include "../nonnon/project/macro.c"




#define N_PAINT_COLORHISTORY_OFFSET (  2 )
#define N_PAINT_COLORHISTORY_COUNT  ( 10 )




static HWND  n_paint_colorhistory_hgui;
static n_bmp n_paint_colorhistory_nbmp;
static n_bmp n_paint_colorhistory_dbuf;
static u32   n_paint_colorhistory_color[ N_PAINT_COLORHISTORY_COUNT ];




void
n_paint_colorhistory_init( void )
{

	n_paint_colorhistory_color[ 0 ] = n_bmp_black;
	n_paint_colorhistory_color[ 1 ] = n_bmp_white;
	n_paint_colorhistory_color[ 2 ] = n_bmp_rgb(   0,200,255 );
	n_paint_colorhistory_color[ 3 ] = n_bmp_rgb( 255,  0,200 );
	n_paint_colorhistory_color[ 4 ] = n_bmp_rgb( 200,255,  0 );
	n_paint_colorhistory_color[ 5 ] = n_bmp_rgb(   0,255,200 );
	n_paint_colorhistory_color[ 6 ] = n_bmp_rgb( 200,  0,255 );
	n_paint_colorhistory_color[ 7 ] = n_bmp_rgb( 255,200,  0 );
	n_paint_colorhistory_color[ 8 ] = n_bmp_rgb(   0,200,255 );
	n_paint_colorhistory_color[ 9 ] = n_bmp_rgb(   0,200,255 );


	return;
}

void
n_paint_colorhistory_add( u32 color )
{

	int i = 0;
	while( 1 )
	{

		if ( n_paint_colorhistory_color[ i ] == color ) { return; }


		i++;
		if ( i >= N_PAINT_COLORHISTORY_COUNT ) { break; }
	}


	memmove
	(
		&n_paint_colorhistory_color[ N_PAINT_COLORHISTORY_OFFSET + 1 ],
		&n_paint_colorhistory_color[ N_PAINT_COLORHISTORY_OFFSET + 0 ],
		sizeof(u32) * ( N_PAINT_COLORHISTORY_COUNT - 1 - N_PAINT_COLORHISTORY_OFFSET )
	);

	n_paint_colorhistory_color[ N_PAINT_COLORHISTORY_OFFSET ] = color;


	return;
}

// internal
void
n_paint_colorhistory_move( HWND hwnd )
{

	s32 ctl; n_win_stdsize( hwnd, &ctl, NULL, NULL );


	s32 csx = ctl * N_PAINT_COLORHISTORY_COUNT;
	s32 csy = ctl * N_PAINT_COLORHISTORY_COUNT;

	n_win_set( hwnd, NULL, csx,csy, N_WIN_SET_CENTERING );

	n_win_move_simple( n_paint_colorhistory_hgui, 0,0, csx,csy, n_false );


	return;
}

void
n_paint_colorhistory_text( n_bmp *bmp, s32 sx, s32 sy, int ctl, u32 color )
{

	n_gdi gdi; n_gdi_zero( &gdi );

	gdi.sx                  = sx;
	gdi.sy                  = ctl;
	gdi.scale               = N_GDI_SCALE_AUTO;

	//gdi.frame_style         = N_GDI_FRAME_SIMPLE;

	int a = n_bmp_a( color );
	int r = n_bmp_r( color );
	int g = n_bmp_g( color );
	int b = n_bmp_b( color );

	int              cb = sizeof( NONCLIENTMETRICS );
	NONCLIENTMETRICS ncm; ZeroMemory( &ncm, cb );

	ncm.cbSize = cb;
	SystemParametersInfo( SPI_GETNONCLIENTMETRICS, cb, &ncm, 0 );

	n_posix_char str[ 100 ]; n_posix_sprintf_literal( str, "%3d / %3d / %3d / %3d", a, r, g, b );

	gdi.text                = str;
	gdi.text_font           = ncm.lfMessageFont.lfFaceName;
	gdi.text_size           = ncm.lfMessageFont.lfHeight;
	gdi.text_style          = N_GDI_TEXT_SMOOTH | N_GDI_TEXT_CONTOUR;
	gdi.text_color_main     = n_bmp_white;
	gdi.text_color_contour  = n_bmp_black;
	gdi.text_fxsize2        = n_win_dpi( hwnd_main ) / 96;


	n_bmp_free( bmp );
	n_gdi_bmp( &gdi, bmp );


	return;
}

LRESULT CALLBACK
n_paint_colorhistory_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_CREATE :


		// Global

		n_win_ime_disable( hwnd );

		n_bmp_zero( &n_paint_colorhistory_nbmp );
		n_bmp_zero( &n_paint_colorhistory_dbuf );


		// Window

		n_win_init_literal( hwnd, "History", "NONNON_PAINT_3_0_COLOR", "" );

		n_win_gui_literal( hwnd, CANVAS, "", &n_paint_colorhistory_hgui );


		// Style

		n_win_exstyle_new( hwnd, WS_EX_DLGMODALFRAME );
		n_win_style_new  ( hwnd, N_WS_POPUPWINDOW );

		n_win_sysmenu_disable( hwnd, 1,0,1, 1,1, 0, 0 );

		n_win_style_add( n_paint_colorhistory_hgui , SS_NOTIFY );


		// Size

		n_paint_colorhistory_move( hwnd );


		// Display

		ShowWindowAsync( hwnd, SW_NORMAL );

		EnableWindow( hwnd_tool, n_false );
		EnableWindow( hwnd_layr, n_false );
		EnableWindow( hwnd_main, n_false );

	break;


	case WM_KEYDOWN :

		if ( wparam == VK_ESCAPE )
		{
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );
		} else

		if ( wparam == N_PAINT_KEY_J )
		{
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );
		}

	break;

	case WM_COMMAND :
	{

		if ( STN_CLICKED != HIWORD( wparam ) ) { break; }


		s32 x,y; n_win_cursor_position_relative( n_paint_colorhistory_hgui, &x, &y );


		extern n_win_colorpicker cp;

		u32 c; n_bmp_ptr_get( &n_paint_colorhistory_nbmp, x,y, &c );

		int a = n_bmp_a( c );
		int r = n_bmp_r( c );
		int g = n_bmp_g( c );
		int b = n_bmp_b( c );

		nwclr_refresh( &cp, a,r,g,b );


		n_win_message_send( hwnd, WM_CLOSE, 0,0 );

	}
	break;


	case WM_CLOSE :

		EnableWindow( hwnd_tool, n_true );
		EnableWindow( hwnd_layr, n_true );
		EnableWindow( hwnd_main, n_true );

		ShowWindow( hwnd, SW_HIDE );


		n_bmp_free( &n_paint_colorhistory_nbmp );
		n_bmp_free( &n_paint_colorhistory_dbuf );


		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		//PostQuitMessage( 0 );

	break;


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;

		if ( di == NULL ) { break; }

		if ( n_paint_colorhistory_hgui != di->hwndItem ) { break; }


		s32 ctl; n_win_stdsize( hwnd, &ctl, NULL, NULL );
		s32 sx,sy; n_win_size( n_paint_colorhistory_hgui, &sx, &sy );

		n_bmp_new( &n_paint_colorhistory_nbmp, sx,sy );

		s32 tsx = ( sx / 5 ) + ( sx % 5 );

		int i = 0;
		while( 1 )
		{

			u32 color   = n_paint_colorhistory_color[ i ];
			u32 color_0 = n_bmp_gamma_pixel( color, 0.5 );
			u32 color_1 = n_bmp_gamma_pixel( color, 1.0 );
			u32 color_2 = n_bmp_gamma_pixel( color, 1.5 );

			s32 x = 0;
			n_bmp_box( &n_paint_colorhistory_nbmp, x, ctl * i, tsx * 1, ctl, color_0 ); x += tsx;
			n_bmp_box( &n_paint_colorhistory_nbmp, x, ctl * i, tsx * 3, ctl, color_1 ); x += tsx * 3;
			n_bmp_box( &n_paint_colorhistory_nbmp, x, ctl * i, tsx * 1, ctl, color_2 ); //x += tsx;

			i++;
			if ( i >= N_PAINT_COLORHISTORY_COUNT ) { break; }
		}


		n_bmp_free( &n_paint_colorhistory_dbuf );
		n_bmp_carboncopy( &n_paint_colorhistory_nbmp, &n_paint_colorhistory_dbuf );

		n_bmp bmp; n_bmp_zero( &bmp );

		i = 0;
		while( 1 )
		{//break;

			u32 color = n_paint_colorhistory_color[ i ];

			n_paint_colorhistory_text( &bmp, sx,sy, ctl, color );
//n_bmp_save_literal( &bmp, "ret.bmp" );

			n_bmp_transcopy( &bmp, &n_paint_colorhistory_dbuf, 0,0,sx,ctl, 0,ctl * i );

			i++;
			if ( i >= N_PAINT_COLORHISTORY_COUNT ) { break; }
		}

		n_bmp_free( &bmp );


		n_gdi_bitmap_draw( n_paint_colorhistory_hgui, &n_paint_colorhistory_dbuf, 0,0,sx,sy, 0,0 );

	}
	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

