// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




void
n_paint_grabNdrag_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static POINT prv, cur;


	switch( msg ) {


	case WM_MBUTTONDOWN :

		if ( wparam & MK_SHIFT   ) { break; }
		if ( wparam & MK_CONTROL ) { break; }


		n_win_cursor_add_literal( NULL, "NONNON_PAINT_PAW_ON" );

		SetCapture( hwnd );

		GetCursorPos( &prv );

		n_paint_grabNdrag_onoff = n_true;

	break;

	case WM_MOUSEMOVE :
	{

		if ( wparam & MK_SHIFT   ) { break; }
		if ( wparam & MK_CONTROL ) { break; }


		if ( n_paint_grabNdrag_onoff == n_false ) { break; }


		GetCursorPos( &cur );

		prv.x -= cur.x;
		prv.y -= cur.y;

		nwin_main.scrollx += prv.x;
		nwin_main.scrolly += prv.y;

		prv = cur;


		extern void n_paint_refresh_calc( void );
		n_paint_refresh_calc();

		n_paint_hscr.unit_pos = nwin_main.scrollx;
		n_paint_vscr.unit_pos = nwin_main.scrolly;

		n_win_scrollbar_draw_always( &n_paint_hscr, n_true );
		n_win_scrollbar_draw_always( &n_paint_vscr, n_true );

		n_paint_refresh_client();

	}
	break;


	case WM_MBUTTONUP :

		//if ( wparam & MK_SHIFT   ) { break; }
		if ( wparam & MK_CONTROL ) { break; }


		n_paint_grabNdrag_onoff = n_false;

		ReleaseCapture();

		n_paint_pen_cursor_default( NULL );

	break;


	} // switch


	return;
}

