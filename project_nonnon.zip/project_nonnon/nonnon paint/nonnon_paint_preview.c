// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




// the base layer

#include "../nonnon/neutral/bmp/all.c"
#include "../nonnon/win32/win.c"

#include "../nonnon/project/macro.c"




static s32 n_paint_preview_default_sx = -1;
static s32 n_paint_preview_default_sy = -1;




// internal
void
n_paint_preview_cache_exit( HWND hwnd, n_bmp *bmp_cache )
{

	n_bmp_free( bmp_cache );


	return;
}

// internal
void
n_paint_preview_cache_init( HWND hwnd, n_bmp *bmp_cache )
{

	n_paint_preview_cache_exit( hwnd, bmp_cache );


	s32 tsx,tsy; n_win_size_client( hwnd, &tsx, &tsy );


	s32 bmpsx = tsx;
	s32 bmpsy = tsy;

	if ( n_bmp_error( n_paint_bmp_data ) )
	{

		n_bmp_new( bmp_cache, bmpsx, bmpsy );

	} else {

		bmpsx = N_BMP_SX( n_paint_bmp_data );
		bmpsy = N_BMP_SY( n_paint_bmp_data );

		if ( n_paint_layer_onoff == n_false )
		{
			n_bmp_carboncopy( n_paint_bmp_data, bmp_cache );

			n_paint_grabber_composition( n_paint_bmp_grab, bmp_cache, n_true, n_true );
		} else {
			n_bmp_new( bmp_cache, bmpsx, bmpsy );
			n_bmp_layercopy( n_paint_layer_data, bmp_cache, 0,0, bmpsx,bmpsy, 0,0, n_true );
		}

	}


	if ( ( bmpsx > tsx )||( bmpsy > tsy ) )
	{

		double ratio = 1.0;

		if ( bmpsx > bmpsy )
		{
			ratio = (double) tsx / bmpsx;
		} else {
			ratio = (double) tsy / bmpsy;
		}

		n_bmp_resampler( bmp_cache, ratio, ratio );

	}


	if ( n_paint_format == N_PAINT_FORMAT_ICO )
	{

		u32 color_bg;
		if ( n_win_darkmode_onoff )
		{
			color_bg = n_bmp_black;
		} else {
			color_bg = n_gdi_systemcolor( COLOR_WINDOW );
		}

		n_bmp_resizer( bmp_cache, tsx,tsy, color_bg, N_BMP_RESIZER_CENTER );
		n_bmp_flush_replacer( bmp_cache, n_bmp_trans, color_bg );

	} else
	if ( n_paint_format == N_PAINT_FORMAT_CUR )
	{

		u32 color_bg = n_gdi_systemcolor( COLOR_DESKTOP );

		n_bmp_resizer( bmp_cache, tsx,tsy, color_bg, N_BMP_RESIZER_CENTER );
		n_bmp_flush_replacer( bmp_cache, n_bmp_trans, color_bg );

	} else {

		n_bmp_resizer( bmp_cache, tsx,tsy, n_bmp_black_invisible, N_BMP_RESIZER_CENTER );

	}


	return;
}

void
n_paint_preview_resize( HWND hwnd )
{

	s32 cs = (double) n_posix_min_s32( n_paint_desktop_sx, n_paint_desktop_sy ) * 0.8;

	n_win_set( hwnd, NULL, cs, cs, N_WIN_SET_CENTERING );


	return;
}

void
n_paint_preview_draw( HWND hwnd, const n_bmp *bmp )
{

	if ( n_bmp_error( bmp ) ) { return; }


	HDC hdc = GetDC( hwnd );
	if ( hdc == NULL ) { return; }


	BITMAPINFO bi = { N_BMP_INFOH( bmp ), { { 0,0,0,0 } } };

	HBITMAP hbmp = CreateDIBitmap
	(
		hdc,
		&bi.bmiHeader,
		CBM_INIT,
		N_BMP_PTR( bmp ),
		&bi,
		DIB_RGB_COLORS
	);


	s32 fsx = N_BMP_SX( bmp );
	s32 fsy = N_BMP_SY( bmp );

	s32 tsx,tsy;
	n_win_size_client( hwnd, &tsx, &tsy );

	if ( n_paint_preview_default_sx == -1 ) { n_paint_preview_default_sx = tsx; }
	if ( n_paint_preview_default_sy == -1 ) { n_paint_preview_default_sy = tsy; }

	n_win_hwndprintf_literal
	(
		hwnd,
		"Preview : X %dpx (%d%%) : Y %dpx (%d%%)",
		tsx - n_paint_preview_default_sx,
		(int) trunc( (double) tsx / n_paint_preview_default_sx * 100 ),
		tsy - n_paint_preview_default_sy,
		(int) trunc( (double) tsy / n_paint_preview_default_sy * 100 )
	);


	HDC     hdc_compat = CreateCompatibleDC( hdc );
	HBITMAP hbmp_old   = SelectObject( hdc_compat, hbmp );

	SetStretchBltMode( hdc, COLORONCOLOR );
	StretchBlt( hdc, 0,0,tsx,tsy, hdc_compat, 0,0,fsx,fsy, SRCCOPY );

	SelectObject( hdc_compat, hbmp_old );
	DeleteDC( hdc_compat );


	n_win_bitmap_exit( hbmp );

	ReleaseDC( hwnd, hdc );


	return;
}

LRESULT CALLBACK
n_paint_preview_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_bmp bmp_cache;


	n_win_simplemenu_xmouse( &n_paint_simplemenu, hwnd, msg );


	switch( msg ) {


	case WM_CREATE :


		// Global

		n_win_ime_disable( hwnd );

		n_bmp_zero( &bmp_cache );


		n_paint_preview_default_sx = -1;
		n_paint_preview_default_sy = -1;


		// Window

		n_win_init_literal( hwnd, "Preview", "NONNON_PAINT_0_MAIN", "" );


		// Style

		n_win_style_new( hwnd, N_WS_POPUPWINDOW | WS_SIZEBOX );
		//n_win_style_new( hwnd, WS_POPUP | WS_SIZEBOX );

		if ( n_project_dwm_is_on() ) { n_win_dwm_transparent_on( hwnd ); }


		// Init

		if (
			( n_posix_stat_is_exist( n_paint_bmpname ) )
			&&
			( n_paint_format_is_cur( n_paint_bmpname ) )
		)
		{
			n_win_cursor_add( hwnd, n_paint_bmpname );
		}

		n_paint_preview_resize( hwnd );
		n_paint_preview_cache_init( hwnd, &bmp_cache );
		n_paint_preview_draw( hwnd, &bmp_cache );


		// Display

		ShowWindowAsync( hwnd, SW_NORMAL );

		EnableWindow( hwnd_tool, n_false );
		EnableWindow( hwnd_layr, n_false );
		EnableWindow( hwnd_main, n_false );

	break;


	case WM_ERASEBKGND :

		return n_true;

	break;

	case WM_PAINT :
	case WM_SIZE  :

		n_paint_preview_draw( hwnd, &bmp_cache );

	break;


	case WM_LBUTTONDBLCLK :

		n_paint_preview_resize( hwnd );
		//n_paint_preview_cache_init( hwnd, &bmp_cache );
		n_paint_preview_draw( hwnd, &bmp_cache );

	break;


	case WM_KEYDOWN :

		// [!] : for toggling : see n_paint_tool_input_proc()

		if ( wparam == VK_ESCAPE )
		{
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );
		} else

		if ( wparam == N_PAINT_KEY_1 )
		{
			n_win_message_send( hwnd, WM_CLOSE, 0,0 );
		}

	break;


	case WM_CLOSE :

		EnableWindow( hwnd_tool, n_true );
		EnableWindow( hwnd_layr, n_true );
		EnableWindow( hwnd_main, n_true );

		ShowWindow( hwnd, SW_HIDE );


		n_paint_preview_cache_exit( hwnd, &bmp_cache );

		n_win_cursor_del( hwnd );

		DestroyWindow( hwnd );

	break;


	} // switch


	n_paint_sync_proc( hwnd, msg, wparam, lparam );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

