// Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [!] : don't use "posix.c" in this file


// Debug Facility : don't use as main release
//
//	"#define N_MEMORY_DEBUG" to turn ON





#ifndef _H_NONNON_NEUTRAL_MEMORY
#define _H_NONNON_NEUTRAL_MEMORY




#include "./type.c"


#include <stdlib.h>
#include <string.h>




// [!] : use when logic is safely closed
//
//	a : allocated memory will be overwritten immediately
//	b : allocated memory will be freed in narrow scope

#define n_memory_new_closed  n_memory_new
#define n_memory_free_closed n_memory_free




// [!] : malloc() limits size_t
//
//	currently, do exit() when gets over limit

#define N_MEMORY_COUNT_MAX ULONG_MAX




#ifdef N_MEMORY_DEBUG


#ifdef N_POSIX_PLATFORM_WINDOWS

#include "../win32/win/mutex.c"

#endif // #ifdef N_POSIX_PLATFORM_WINDOWS


#endif // #ifdef N_MEMORY_DEBUG




#ifdef N_MEMORY_DEBUG


static s64 n_memory_refcount = 0;


#else // #ifdef N_MEMORY_DEBUG


#define n_memory_refcount 0


#endif // #ifdef N_MEMORY_DEBUG




void
n_memory_debug_refcount( void )
{

#ifdef N_MEMORY_DEBUG

	char str[ 100 ];

	sprintf( str, "%d", n_memory_refcount );

	MessageBoxA( NULL, str, "DEBUG", MB_TOPMOST | MB_OK );


#endif // #ifdef N_MEMORY_DEBUG

	return;
}

void
n_memory_debug_on( void )
{

#ifdef N_MEMORY_DEBUG

	atexit( n_memory_debug_refcount );

#endif // #ifdef N_MEMORY_DEBUG

	return;
}

void*
n_memory_new( s64 byte )
{

	// [!] : free() equivalent behavior

	if ( byte == 0 )
	{
		return NULL;
	}


	// [!] : not supported by POSIX

	if ( byte > N_MEMORY_COUNT_MAX ) { exit( 0 ); }

	if ( byte < 0 ) { exit( 0 ); }


	void *ptr = malloc( byte );


	// [!] : currently, not supported

	if ( ptr == NULL ) { exit( 0 ); }

	//memset( ptr, 0, byte );


#ifdef N_MEMORY_DEBUG

	// [!] : scrambling

	memset( ptr, rand(), byte );


#ifdef N_POSIX_PLATFORM_WINDOWS

	HANDLE hmutex = n_win_mutex_init_and_wait_literal( NULL, "n_memory_new()" );

	n_memory_refcount++;

	hmutex = n_win_mutex_exit( hmutex );

#else  // #ifdef N_POSIX_PLATFORM_WINDOWS

	n_memory_refcount++;

#endif // #ifdef N_POSIX_PLATFORM_WINDOWS


#endif // #ifdef N_MEMORY_DEBUG


	return ptr;
}

void
n_memory_free( void *ptr )
{

	if ( ptr == NULL ) { return; }


	free( ptr );


#ifdef N_MEMORY_DEBUG


#ifdef N_POSIX_PLATFORM_WINDOWS

	HANDLE hmutex = n_win_mutex_init_and_wait_literal( NULL, "n_memory_free()" );

	if ( n_memory_refcount >= 1 ) { n_memory_refcount--; }

	hmutex = n_win_mutex_exit( hmutex );

#else  // #ifdef N_POSIX_PLATFORM_WINDOWS

	if ( n_memory_refcount >= 1 ) { n_memory_refcount--; }

#endif // #ifdef N_POSIX_PLATFORM_WINDOWS


#endif // #ifdef N_MEMORY_DEBUG


	return;
}

void*
n_memory_resize( void* ptr, s64 byte )
{

	// [!] : free() equivalent behavior

	if ( byte == 0 )
	{

		n_memory_free( ptr );

		return NULL;
	}


	// [!] : not supported by POSIX

	if ( byte > N_MEMORY_COUNT_MAX ) { exit( 0 ); }

	if ( byte < 0 ) { exit( 0 ); }


	void *ret = realloc( ptr, byte );


	// [!] : currently, not supported

	if ( ret == NULL ) { exit( 0 ); }


#ifdef N_MEMORY_DEBUG


#ifdef N_POSIX_PLATFORM_WINDOWS

	HANDLE hmutex = n_win_mutex_init_and_wait_literal( NULL, "n_memory_resize()" );

	if ( ptr == NULL ) { n_memory_refcount++; }

	hmutex = n_win_mutex_exit( hmutex );

#else  // #ifdef N_POSIX_PLATFORM_WINDOWS

	if ( ptr == NULL ) { n_memory_refcount++; }

#endif // #ifdef N_POSIX_PLATFORM_WINDOWS


#endif // #ifdef N_MEMORY_DEBUG


	return ret;
}




#define n_memory_zero( ptr, byte ) n_memory_padding( ptr, 0, byte )

void
n_memory_padding( void *ptr, char c, s64 byte )
{

	if ( ptr  == NULL ) { return; }
	if ( byte <=    0 ) { return; }


	memset( ptr, c, byte );


	return;
}

void
n_memory_padding_int( int *ptr, int c, s64 count )
{

	// [!] : count = byte / sizeof( int )


	if ( ptr == NULL ) { return; }


	s64 i = 0;
	while( 1 )
	{

		ptr[ i ] = c;

		i++;
		if ( i >= count ) { break; }
	}


	return;
}

int
n_memory_is_same( const void *a, const void *b, s64 byte )
{

	if ( a    == NULL ) { return 0; }
	if ( b    == NULL ) { return 0; }
	if ( byte ==    0 ) { return 0; }


	return ( 0 == memcmp( a, b, byte ) );
}

void
n_memory_copy( const void *f, void *t, s64 byte )
{

	if ( f    == NULL ) { return; }
	if ( t    == NULL ) { return; }
	if ( byte ==    0 ) { return; }


	//memcpy( t, f, byte );
	memmove( t, f, byte );


	return;
}




void*
n_memory_element_add( void *p, s64 align, s64 count, s64 index )
{

	if ( p == NULL ) { return NULL; }

	if ( align == 0 ) { return NULL; }
	if ( count == 0 ) { return NULL; }

	// [!] : index == count is acceptable

	if ( index > count ) { return NULL; }


	count++;

	s64   all  = align * count;
	s64   prev = align * index;
	s64   next = prev  + align;
	char *ptr  = (char*) n_memory_resize( p, all );

	if ( next != all )
	{
		n_memory_copy( &ptr[ prev ], &ptr[ next ], all - next );
	}

	n_memory_padding( &ptr[ prev ], 0, align );


	return ptr;
}

void*
n_memory_element_del( void *p, s64 align, s64 count, s64 index )
{

	if ( p == NULL ) { return NULL; }

	if ( align <= 0 ) { return NULL; }
	if ( count <= 0 ) { return NULL; }

	if ( index >= count ) { return NULL; }


	s64   all  = align * count;
	s64   prev = align * index;
	s64   next = prev  + align;
	char *ptr  = (char*) p;

	if ( prev != all )
	{
		n_memory_copy( &ptr[ next ], &ptr[ prev ], all - next );
	}


	// [!] : malloc() compatible behavior

	p = n_memory_resize( p, all - align );
	if ( p == NULL ) { p = malloc( 0 ); }


	return p;
}

void
n_memory_element_swap( void *p, s64 align, s64 index_1, s64 index_2 )
{

	if ( p == NULL ) { return; }

	if ( align == 0 ) { return; }

	if ( index_1 == index_2 ) { return; }


	index_1 *= align;
	index_2 *= align;

	char *ptr = (char*) p;
	char *elm = (char*) n_memory_new_closed( align );

	n_memory_copy( &ptr[ index_1 ],             elm, align );
	n_memory_copy( &ptr[ index_2 ], &ptr[ index_1 ], align );
	n_memory_copy(             elm, &ptr[ index_2 ], align );

	n_memory_free_closed( elm );


	return;
}


#endif // _H_NONNON_NEUTRAL_MEMORY

