// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [!] : don't use "_transparent.c" : the first layer only




#ifndef _H_NONNON_NEUTRAL_BMP_DRAW
#define _H_NONNON_NEUTRAL_BMP_DRAW




#include <math.h>




#include "../bmp.c"


#include "./_error.c"
#include "./_fastcopy.c"
#include "./color.c"
#include "./detect.c"




s64
n_bmp_fill( n_bmp *bmp, s32 x, s32 y, u32 color )
{

	// [!] : return value : processed pixel count


	if ( n_bmp_error( bmp ) ) { return 0; }


	// [!] : fail-safe

	u32 color_to;

	n_bmp_ptr_get( bmp, x,y, &color_to );
	if ( color == color_to ) { return 0; }


	// [!] : the same performance between these two logics

	//int *map = n_memory_new_closed( N_BMP_SX( bmp ) * N_BMP_SY( bmp ) * sizeof( int ) );
	u8 *map = (u8*) n_memory_new_closed( N_BMP_SX( bmp ) * N_BMP_SY( bmp ) * sizeof( u8 ) );


	u32 t     = 0;
	int move  = 0;
	int stop  = 0;
	s64 count = 0;
	u32 i     = 0;
	while( 1 )
	{

		if (
			( n_posix_false == n_bmp_ptr_get( bmp, x,y, &t ) )
			&&
			( t == color_to )
		)
		{

			stop = 0;

			n_bmp_ptr_set_fast( bmp, x,y, color ); count++;

			map[ i ] = move;

			i++;

		} else {

			if ( move == 0 ) { y++; } else
			if ( move == 1 ) { x--; } else
			if ( move == 2 ) { y--; } else
			if ( move == 3 ) { x++; }

			stop++;
			if ( stop >= 4 )
			{

				stop = 0;

				if ( i <= 1 ) { break; }


				i--;

				move = map[ i ];
				if ( move == 0 ) { y++; } else
				if ( move == 1 ) { x--; } else
				if ( move == 2 ) { y--; } else
				if ( move == 3 ) { x++; }

			}

			move++;
			if ( move >= 4 ) { move = 0; }

		}

		if ( move == 0 ) { y--; } else
		if ( move == 1 ) { x++; } else
		if ( move == 2 ) { y++; } else
		if ( move == 3 ) { x--; }

	}


	n_memory_free_closed( map );


	return count;
}

#define n_bmp_line( b, fx,fy,tx,ty, c ) n_bmp_line_dot( b, fx,fy,tx,ty, c, 0 )

void
n_bmp_line_dot( n_bmp *bmp, s32 fx, s32 fy, s32 tx, s32 ty, u32 color, int moire )
{

	if ( n_bmp_error( bmp ) ) { return; }


	double step = 0;
	double unit = (double) abs( fy - ty ) / n_posix_max_s32( 1, abs( fx - tx ) );


	while( 1 )
	{

		// [!] : need to draw the first pos

		if ( n_bmp_moire_detect( fx, fy, moire ) )
		{
			n_bmp_ptr_set( bmp, fx,fy, color );
		}


		// [!] : need to draw tx,ty once or more

		if ( ( fx == tx )&&( fy == ty ) ) { break; }


		// [!] : don't use "else" : avoid zig-zag

		if ( step < 1 )
		{
			step += unit;
			if ( fx > tx ) { fx--; } else if ( fx < tx ) { fx++; }
		}

		if ( step >= 1 )
		{
			step -= 1;
			if ( fy > ty ) { fy--; } else if ( fy < ty ) { fy++; }
		}

	}


	return;
}

typedef struct {

	n_bmp *bmp;
	s32    x,y,sx,sy;
	s32    bmpsx,bmpsy;
	u32    color;
	u32    oy, cores;

} n_bmp_box_thread_struct;

void
n_bmp_box_thread_main( n_bmp_box_thread_struct *p )
{

	s32 line = p->bmpsx * ( p->bmpsy - 1 - p->y - p->oy );
	s32 jump = p->bmpsx * p->cores;


	s32 ty = p->oy; if ( ty >= p->sy ) { return; }
	while( 1 )
	{

		s32 pos = p->x + line;

		s32 tx = 0;
		while( 1 )
		{

			N_BMP_PTR( p->bmp )[ pos + tx ] = p->color;

			tx++;
			if ( tx >= p->sx ) { break; }
		}

		line -= jump;

		ty += p->cores;
		if ( ty >= p->sy ) { return; }
	}


	return;
}

n_thread_return
n_bmp_box_thread( n_thread_argument p )
{

	n_bmp_box_thread_main( (n_bmp_box_thread_struct*) p );

	return 0;
}

void
n_bmp_box( n_bmp *bmp, s32 x, s32 y, s32 sx, s32 sy, u32 color )
{

	if ( n_bmp_error_clipping( bmp,NULL, &x,&y,&sx,&sy, NULL,NULL ) ) { return; }


	// [x] : Win9x : can run but not working

	if (
		( n_thread_onoff() )
		&&
		( ( sx * sy ) >= N_BMP_MULTITHREAD_GRANULARITY )
	)
	{

#ifdef N_BMP_MULTITHREAD_DEBUG

		n_posix_debug_literal( " n_bmp_box() " );

#endif // #ifdef N_BMP_MULTITHREAD_DEBUG


		n_posix_bool p_multithread = n_bmp_is_multithread;
		n_bmp_is_multithread = n_posix_true;


		u32 cores = n_thread_core_count;

		n_thread                *h = (n_thread               *) n_memory_new( cores * sizeof( n_thread                ) );
		n_bmp_box_thread_struct *p = (n_bmp_box_thread_struct*) n_memory_new( cores * sizeof( n_bmp_box_thread_struct ) );


		s32 bmpsx = N_BMP_SX( bmp );
		s32 bmpsy = N_BMP_SY( bmp );


		u32 i = 0;
		while( 1 )
		{

			n_bmp_box_thread_struct tmp = { bmp, x,y,sx,sy, bmpsx,bmpsy, color, i,cores };
			n_memory_copy( &tmp, &p[ i ], sizeof( n_bmp_box_thread_struct ) );

			h[ i ] = n_thread_init( n_bmp_box_thread, &p[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		while( 1 )
		{

			n_thread_wait( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		while( 1 )
		{

			n_thread_exit( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}


		n_memory_free( h );
		n_memory_free( p );


		n_bmp_is_multithread = p_multithread;

	} else {

		n_bmp_box_thread_struct p = { bmp, x,y,sx,sy, N_BMP_SX( bmp ),N_BMP_SY( bmp ), color, 0,1 };

		n_bmp_box_thread_main( &p );

	}


	return;
}

#define N_BMP_GRADIENT_CENTERING  ( 0 << 16 )
#define N_BMP_GRADIENT_HORIZONTAL ( 1 << 16 )
#define N_BMP_GRADIENT_VERTICAL   ( 2 << 16 )
#define N_BMP_GRADIENT_TOPLEFT    ( 3 << 16 )

#define n_bmp_flush_gradient( bmp, from,to, option ) \
	n_bmp_gradient( bmp, 0,0,N_BMP_SX( bmp ),N_BMP_SY( bmp ), from,to, option )

typedef struct {

	n_bmp *bmp;
	s32    x,y,sx,sy;
	s32    size;
	s32    centerx, centery;
	int    type, mode;
	u32    from, to;
	u32    oy, cores;

} n_bmp_gradient_thread_struct;

void
n_bmp_gradient_thread_main( n_bmp_gradient_thread_struct *p )
{

	// [!] : random-dot based dither

	const int randomdot_max  = 3;
	const int randomdot_half = randomdot_max / 2;

	n_posix_bool randomdot_onoff = n_posix_true;


	// [!] : convolution based dither

	const int dither_sx = 2;
	const int dither_sy = 2;

	const int dither_map[] = {

		0, 3,
		3, 0,

	};


	s32 tx = 0;
	s32 ty = p->oy; if ( ty >= p->sy ) { return; }
	while( 1 )
	{

		s32 fx = 0;
		s32 fy = 0;

		if ( p->type != N_BMP_GRADIENT_VERTICAL   ) { fx = p->centerx - tx; }
		if ( p->type != N_BMP_GRADIENT_HORIZONTAL ) { fy = p->centery - ty; }


		u32 color = n_bmp_gradient_pixel( p->from,p->to, fx,fy, p->size, p->mode );


		int d = dither_map[ abs( fx % dither_sx ) + ( dither_sx * abs( fy % dither_sy ) ) ];

		if ( randomdot_onoff )
		{
			d += n_random_range( randomdot_max ) - randomdot_half;
		}

		// [!] : alpha is not used

		int a = n_bmp_a( color );
		int r = n_bmp_clamp_channel( n_bmp_r( color ) + d );
		int g = n_bmp_clamp_channel( n_bmp_g( color ) + d );
		int b = n_bmp_clamp_channel( n_bmp_b( color ) + d );

		color = n_bmp_argb( a,r,g,b );


		n_bmp_ptr_set( p->bmp, tx + p->x, ty + p->y, color );


		tx++;
		if ( tx >= p->sx )
		{

			tx = 0;

			ty += p->cores;
			if ( ty >= p->sy ) { break; }
		}
	}


	return;
}

n_thread_return
n_bmp_gradient_thread( n_thread_argument p )
{

	n_bmp_gradient_thread_main( (n_bmp_gradient_thread_struct*) p );

	return 0;
}

void
n_bmp_gradient
(
	n_bmp *bmp,
	s32 x, s32 y, s32 sx, s32 sy,
	u32 from, u32 to,
	int option
)
{

	if ( n_bmp_error_clipping( bmp,NULL, &x,&y,&sx,&sy, NULL,NULL ) ) { return; }


	n_bmp_gradient_thread_struct p_0;


	p_0.bmp = bmp;

	p_0.x  =  x;
	p_0.y  =  y;
	p_0.sx = sx;
	p_0.sy = sy;

	p_0.type = option & 0xffff0000;
	p_0.mode = option & 0x0000ffff;

	p_0.centerx = 0;
	p_0.centery = 0;

	if ( p_0.sx > p_0.sy ) { p_0.size = p_0.sx; } else { p_0.size = p_0.sy; }

	if ( p_0.type == N_BMP_GRADIENT_CENTERING  )
	{
		p_0.size    = p_0.size / 2;
		p_0.centerx = p_0.sx   / 2;
		p_0.centery = p_0.sy   / 2;
	} else
	if ( p_0.type == N_BMP_GRADIENT_HORIZONTAL )
	{
		p_0.size = p_0.sx;
	} else
	if ( p_0.type == N_BMP_GRADIENT_VERTICAL   )
	{
		p_0.size = p_0.sy;
	}

	p_0.from = from;
	p_0.to   =   to;

	p_0.oy    = 0;
	p_0.cores = 1;


	// [x] : Win9x : can run but not working

	if (
//(0)&&
		( n_thread_onoff() )
		&&
		( ( p_0.size * p_0.size ) >= N_BMP_MULTITHREAD_GRANULARITY )
	)
	{

#ifdef N_BMP_MULTITHREAD_DEBUG

		n_posix_debug_literal( " n_bmp_gradient() " );

#endif // #ifdef N_BMP_MULTITHREAD_DEBUG


		n_posix_bool p_multithread = n_bmp_is_multithread;
		n_bmp_is_multithread = n_posix_true;


		u32 cores = n_thread_core_count;

		n_thread                     *h = (n_thread                    *) n_memory_new(cores * sizeof(n_thread));
		n_bmp_gradient_thread_struct *p = (n_bmp_gradient_thread_struct*) n_memory_new( cores * sizeof( n_bmp_gradient_thread_struct ) );


		u32 i = 0;
		while( 1 )
		{

			n_memory_copy( &p_0, &p[ i ], sizeof( n_bmp_gradient_thread_struct ) );

			p[ i ].oy    = i;
			p[ i ].cores = cores;

			h[ i ] = n_thread_init( n_bmp_gradient_thread, &p[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		while( 1 )
		{

			n_thread_wait( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		while( 1 )
		{

			n_thread_exit( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}


		n_memory_free( h );
		n_memory_free( p );


		n_bmp_is_multithread = p_multithread;

	} else {

		n_bmp_gradient_thread_main( &p_0 );

	}


	return;
}

#define n_bmp_flush_roundrect( bmp, color, p ) \
	n_bmp_roundrect( bmp, 0,0,N_BMP_SX( bmp ),N_BMP_SY( bmp ), color, p )

#define n_bmp_roundrect_pixel( b, x,y,sx,sy, c, p ) n_bmp_roundrect( b, x,y,sx,sy, c,  (p) )
#define n_bmp_roundrect_ratio( b, x,y,sx,sy, c, p ) n_bmp_roundrect( b, x,y,sx,sy, c, -(p) )

#define n_bmp_flush_roundrect_pixel( b, c, p ) n_bmp_flush_roundrect( b, c,  (p) )
#define n_bmp_flush_roundrect_ratio( b, c, p ) n_bmp_flush_roundrect( b, c, -(p) )

#define n_bmp_flush_roundrect_coeff( bmp, color, p, coeff ) \
	n_bmp_roundrect_main( bmp, 0,0,N_BMP_SX( bmp ),N_BMP_SY( bmp ), color, p, coeff )

#define n_bmp_roundrect_pixel_coeff( b, x,y,sx,sy, c, p, coeff ) n_bmp_roundrect_coeff( b, x,y,sx,sy, c,  (p), coeff )
#define n_bmp_roundrect_ratio_coeff( b, x,y,sx,sy, c, p, coeff ) n_bmp_roundrect_coeff( b, x,y,sx,sy, c, -(p), coeff )

#define n_bmp_flush_roundrect_pixel_coeff( b, c, p, coeff ) n_bmp_flush_roundrect_coeff( b, c,  (p), coeff )
#define n_bmp_flush_roundrect_ratio_coeff( b, c, p, coeff ) n_bmp_flush_roundrect_coeff( b, c, -(p), coeff )

typedef struct {

	n_bmp *bmp;
	s32    x,y,sx,sy;
	s32    r;
	u32    color;
	double coeff;
	u32    oy, cores;

} n_bmp_roundrect_thread_struct;

void
n_bmp_roundrect_thread_main( n_bmp_roundrect_thread_struct *p )
{

	s32 fx = 0;
	s32 fy = p->oy; if ( fy >= p->sy ) { return; }
	while( 1 )
	{//break;

		if ( n_bmp_ptr_is_accessible( p->bmp, p->x + fx, p->y + fy ) )
		{

			double coeff = 0;
			n_bmp_roundrect_detect_coeff( fx,fy, p->sx,p->sy, p->r, &coeff );

			u32 c;
			n_bmp_ptr_get_fast( p->bmp, p->x + fx, p->y + fy, &c );

			c = n_bmp_blend_pixel( c, p->color, p->coeff + coeff );

			n_bmp_ptr_set( p->bmp, p->x + fx, p->y + fy,  c );

		}


		fx++;
		if ( fx >= p->sx )
		{

			fx = 0;

			fy += p->cores;
			if ( fy >= p->sy ) { break; }
		}
	}


	return;
}

n_thread_return
n_bmp_roundrect_thread( n_thread_argument p )
{

	n_bmp_roundrect_thread_main( (n_bmp_roundrect_thread_struct*) p );

	return 0;
}

#define n_bmp_roundrect(       b, x,y,sx,sy, color, param    ) n_bmp_roundrect_main( b, x,y,sx,sy, color, param, 0 )
#define n_bmp_roundrect_coeff( b, x,y,sx,sy, color, param, c ) n_bmp_roundrect_main( b, x,y,sx,sy, color, param, c )

void
n_bmp_roundrect_main( n_bmp *bmp, s32 x, s32 y, s32 sx, s32 sy, u32 color, int param, double coeff )
{

	// [!] : don't use n_bmp_error_clipping() : drawing error happens

	//if ( n_bmp_error_clipping( bmp,NULL, &x,&y,&sx,&sy, NULL,NULL ) ) { return; }

	if ( n_bmp_error( bmp ) ) { return; }


	// [!] : nothing to do

	if ( ( sx < 0 )||( sy < 0 ) ) { return; }


	// [Mechanism]
	//
	//	a shorter side will be used for radius
	//
	//	param >= 0 : pixels
	//	param <  0 : percentage


	s32 r = n_posix_min_s32( sx, sy ) / 2;
	int p = abs( param );

	if ( param >= 0 )
	{

		if ( r > p ) { r = p; }

	} else {

		double percent = (double) p * 0.01;
		percent = n_posix_min_double( 1.0, percent );

		if ( percent != 0.0 ) { r = (s32) ( (double) r * percent ); }

	}


	// [x] : Win9x : can run but not working

	if (
//(0)&&
		( n_thread_onoff() )
		&&
		( ( sx * sy ) >= N_BMP_MULTITHREAD_GRANULARITY )
	)
	{

#ifdef N_BMP_MULTITHREAD_DEBUG

		n_posix_debug_literal( " n_bmp_roundrect() " );

#endif // #ifdef N_BMP_MULTITHREAD_DEBUG


		n_posix_bool p_multithread = n_bmp_is_multithread;
		n_bmp_is_multithread = n_posix_true;


		u32 cores = n_thread_core_count;

		n_thread                      *h = (n_thread                     *) n_memory_new( cores * sizeof( n_thread                      ) );
		n_bmp_roundrect_thread_struct *p = (n_bmp_roundrect_thread_struct*) n_memory_new( cores * sizeof( n_bmp_roundrect_thread_struct ) );


		u32 i = 0;
		while( 1 )
		{

			n_bmp_roundrect_thread_struct tmp = { bmp, x,y,sx,sy, r, color, coeff, i,cores };
			n_memory_copy( &tmp, &p[ i ], sizeof( n_bmp_roundrect_thread_struct ) );

			h[ i ] = n_thread_init( n_bmp_roundrect_thread, &p[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		while( 1 )
		{

			n_thread_wait( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		while( 1 )
		{

			n_thread_exit( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}


		n_memory_free( h );
		n_memory_free( p );


		n_bmp_is_multithread = p_multithread;

	} else {

		n_bmp_roundrect_thread_struct p = { bmp, x,y,sx,sy, r, color, coeff, 0,1 };

		n_bmp_roundrect_thread_main( &p );

	}


	return;
}

#define n_bmp_flush_circle( bmp, border, color ) \
	n_bmp_circle( bmp, 0,0,N_BMP_SX( bmp ),N_BMP_SY( bmp ), border, color )

void
n_bmp_circle( n_bmp *bmp, s32 x, s32 y, s32 sx, s32 sy, s32 border, u32 color )
{

	// [!] : don't use n_bmp_error_clipping() : circle will be ellipse at canvas border

	//if ( n_bmp_error_clipping( bmp,NULL, &x,&y,&sx,&sy, NULL,NULL ) ) { return; }
	if ( n_bmp_error( bmp ) ) { return; }


	// [!] : ( size - 1 ) : don't use max size

	s32 rx_o = ( sx - 1 ) / 2;
	s32 ry_o = ( sy - 1 ) / 2;
	s32 rx_i = rx_o - border;
	s32 ry_i = ry_o - border;


	s32 fx = 0;
	s32 fy = 0;
	while( 1 )
	{

		if ( n_bmp_ptr_is_accessible( bmp, x + fx, y + fy ) )
		{

			s32 polar_x = fx - rx_o;
			s32 polar_y = fy - ry_o;

			double coeff_o;
			if ( n_bmp_ellipse_detect_coeff( polar_x,polar_y, rx_o,ry_o, &coeff_o ) )
			{

				double coeff_i;
				if ( n_bmp_ellipse_detect_coeff( polar_x,polar_y, rx_i,ry_i, &coeff_i ) )
				{
					coeff_o = 1.0 - coeff_i;
				}


				u32 c = color;

				if ( coeff_o < 1.0 )
				{
					n_bmp_ptr_get_fast( bmp, x + fx, y + fy, &c );
					c = n_bmp_blend_pixel( c, color, coeff_o );
				}

				if ( coeff_o > 0.0 )
				{
					n_bmp_ptr_set( bmp, x + fx, y + fy,  c );
				}

			}

		}

		fx++;
		if ( fx >= sx )
		{

			fx = 0;

			fy++;
			if ( fy >= sy ) { break; }
		}
	}


	return;
}


#endif //_H_NONNON_NEUTRAL_BMP_DRAW

