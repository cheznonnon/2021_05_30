// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File : see IDataObject.c


// [!] : currently not used because I don't know the mechanism yet




#ifndef _H_NONNON_WIN32_OLE_IENUMFORMATETC
#define _H_NONNON_WIN32_OLE_IENUMFORMATETC




const GUID n_IEnumFORMATETC_guid_IID_IUnknown       = { 0x00000000,0x0000,0x0000,{ 0xC0,0x00, 0x00,0x00,0x00,0x00,0x00,0x46 } };
const GUID n_IEnumFORMATETC_guid_IID_IEnumFORMATETC = { 0x00000103,0x0000,0x0000,{ 0xC0,0x00, 0x00,0x00,0x00,0x00,0x00,0x46 } };




HRESULT __stdcall
n_IEnumFORMATETC_QueryInterface( void *_this, REFIID iid, void **ppvObject )
{

	(*ppvObject) = NULL;

	if (
		( n_memory_is_same( iid, &n_IEnumFORMATETC_guid_IID_IUnknown,       sizeof( GUID ) ) )
		||
		( n_memory_is_same( iid, &n_IEnumFORMATETC_guid_IID_IEnumFORMATETC, sizeof( GUID ) ) )
	)
	{

		(*ppvObject) = _this;

		return S_OK;
	}


	return E_NOINTERFACE;
}

ULONG __stdcall
n_IEnumFORMATETC_AddRef( void *_this )
{
	return S_OK;
}

ULONG __stdcall
n_IEnumFORMATETC_Release( void *_this )
{
	return S_OK;
}

HRESULT __stdcall
n_IEnumFORMATETC_Next( void *_this, ULONG celt, FORMATETC *rgelt, ULONG *pceltFetched )
{
//return S_FALSE;

//n_posix_debug_literal( "IEnumFORMATETC_Next()" );


	if ( celt != 1 ) { return S_FALSE; }


	n_memory_copy( &n_IDataObject_FORMATETC[ n_IDataObject_counter ], rgelt, sizeof( FORMATETC ) );

	n_IDataObject_counter++;
	if ( n_IDataObject_counter >= n_IDataObject_support )
	{

		n_IDataObject_counter = 0;

		return S_FALSE;
	}


	return S_OK;
}

HRESULT __stdcall
n_IEnumFORMATETC_Skip( void *_this, ULONG celt )
{
	return S_FALSE;
}

HRESULT __stdcall
n_IEnumFORMATETC_Reset( void *_this )
{

	n_IDataObject_counter = 0;

	return S_OK;
}

HRESULT __stdcall
n_IEnumFORMATETC_Clone( void *_this, IEnumFORMATETC **ppenum )
{
	return E_OUTOFMEMORY;
}




const void *n_IEnumFORMATETC_Vtbl[] = {

	n_IEnumFORMATETC_QueryInterface,
	n_IEnumFORMATETC_AddRef,
	n_IEnumFORMATETC_Release,

	n_IEnumFORMATETC_Next,
	n_IEnumFORMATETC_Skip,
	n_IEnumFORMATETC_Reset,
	n_IEnumFORMATETC_Clone,

};


static IEnumFORMATETC n_IEnumFORMATETC_instance = { (void*) n_IEnumFORMATETC_Vtbl };




#endif // _H_NONNON_WIN32_OLE_IENUMFORMATETC

