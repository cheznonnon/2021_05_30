// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#define N_WIN_TXTBOX_NAMESPACE              n_posix_literal( "TxtBox" )
#define N_WIN_TXTBOX_NAMESPACE_FOCUS        n_posix_literal( "TxtBox.Focus" )

#define N_WIN_TXTBOX_ALL                    ( -1 )
#define N_WIN_TXTBOX_NOT_SELECTED           ( -1 )

#define N_WIN_TXTBOX_MENU_NONE              ( 0 )
#define N_WIN_TXTBOX_MENU_MAIN              ( 1 )
#define N_WIN_TXTBOX_MENU_LINE              ( 2 )

#define N_WIN_TXTBOX_SMALLBUTTON_MAX        ( 8 )

#define N_WIN_TXTBOX_OPTIMIZATION_NONE      ( 0 )
#define N_WIN_TXTBOX_OPTIMIZATION_SCROLL    ( 1 )
#define N_WIN_TXTBOX_OPTIMIZATION_SHIFT     ( 2 )
#define N_WIN_TXTBOX_OPTIMIZATION_DRAG      ( 3 )
#define N_WIN_TXTBOX_OPTIMIZATION_TYPING    ( 4 )
#define N_WIN_TXTBOX_OPTIMIZATION_CLICK     ( 5 )
#define N_WIN_TXTBOX_OPTIMIZATION_OTHERS    ( 6 )

#define N_WIN_TXTBOX_OPTIMIZATION_SYNC_NONE ( 0 )
#define N_WIN_TXTBOX_OPTIMIZATION_SYNC_ALL  ( 1 )
#define N_WIN_TXTBOX_OPTIMIZATION_SYNC_PART ( 2 )

#define N_WIN_TXTBOX_DRAG_PHASE_NEUTRAL     ( 0 )
#define N_WIN_TXTBOX_DRAG_PHASE_CLICKED     ( 1 )
#define N_WIN_TXTBOX_DRAG_PHASE_STARTED     ( 2 )


#define N_WIN_TXTBOX_STYLE_LISTBOX          ( 1 <<  0 )
#define N_WIN_TXTBOX_STYLE_ONELINE          ( 1 <<  1 )
#define N_WIN_TXTBOX_STYLE_EDITBOX          ( 1 <<  2 )
#define N_WIN_TXTBOX_STYLE_HSCROLL          ( 1 <<  3 )
#define N_WIN_TXTBOX_STYLE_VSCROLL          ( 1 <<  4 )
#define N_WIN_TXTBOX_STYLE_NO_BRDR          ( 1 <<  5 )
#define N_WIN_TXTBOX_STYLE_NO_PDNG          ( 1 <<  6 )
#define N_WIN_TXTBOX_STYLE_STRIPED          ( 1 <<  7 )
#define N_WIN_TXTBOX_STYLE_VISIBLE          ( 1 <<  8 )
#define N_WIN_TXTBOX_STYLE_TRANSBG          ( 1 <<  9 )
#define N_WIN_TXTBOX_STYLE_FLATBDR          ( 1 << 10 )
#define N_WIN_TXTBOX_STYLE_CMB_BDR          ( 1 << 11 )

#define N_WIN_TXTBOX_OPTION_LISTBOX_EFFECTS ( 1 <<  0 )
#define N_WIN_TXTBOX_OPTION_LISTBOX_KEEPSEL ( 1 <<  1 )
#define N_WIN_TXTBOX_OPTION_LISTBOX_HVR2SEL ( 1 <<  2 )
#define N_WIN_TXTBOX_OPTION_ONELINE_HCENTER ( 1 <<  3 )
#define N_WIN_TXTBOX_OPTION_ONELINE_FILENAM ( 1 <<  4 )
#define N_WIN_TXTBOX_OPTION_ONELINE_DIGITAL ( 1 <<  5 )
#define N_WIN_TXTBOX_OPTION_ONELINE_GRAY_ON ( 1 <<  6 )
#define N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM ( 1 <<  7 )
#define N_WIN_TXTBOX_OPTION_EDITBOX_NOIBEAM ( 1 <<  8 )
#define N_WIN_TXTBOX_OPTION_EDITBOX_NOCARET ( 1 <<  9 )
#define N_WIN_TXTBOX_OPTION_EDITBOX_NO_EDIT ( 1 << 10 )
#define N_WIN_TXTBOX_OPTION_NO_FOCUS_CHANGE ( 1 << 11 )
#define N_WIN_TXTBOX_OPTION_ALWAYS_SLOWMODE ( 1 << 12 )
#define N_WIN_TXTBOX_OPTION_ZEROBASED_INDEX ( 1 << 13 )
#define N_WIN_TXTBOX_OPTION_CARET_BLINK_OFF ( 1 << 14 )
#define N_WIN_TXTBOX_OPTION_USE_INPUT_POPUP ( 1 << 15 )
#define N_WIN_TXTBOX_OPTION_COMBOBOX_NOGRAY ( 1 << 16 )
#define N_WIN_TXTBOX_OPTION_STRICT_FOCUS_ON ( 1 << 17 )
#define N_WIN_TXTBOX_OPTION_DELAYEDFOCUS_ON ( 1 << 18 )




typedef struct {

	// Instance : you can control via methods

	HWND    hwnd;
	WNDPROC pfunc;
	n_txt   txt, txt_undo;
	int     style, style_option;

	HBITMAP hbmp;
	n_bmp    bmp;
	n_bmp    bmp_oneline;
	n_bmp   *bmp_backbuffer;

	n_win_scrollbar vscr, hscr;

	s32     scroll_pxl_tabbed_x, scroll_cch_tabbed_y;
	s32     select_cch_x, select_cch_y, select_cch_sx, select_cch_sy;
	s32       undo_cch_x,   undo_cch_y,   undo_cch_sx,   undo_cch_sy;
	s32     offset_pxl_y;

	n_posix_bool partial_selection_from_onoff, partial_selection_to___onoff;
	s32          partial_selection_from_cch_x, partial_selection_to___cch_x;

	n_posix_bool undo_onoff;
	n_posix_bool undo_partial_selection_from_onoff, undo_partial_selection_to___onoff;
	s32          undo_partial_selection_from_cch_x, undo_partial_selection_to___cch_x;

	n_posix_bool              smallbutton_is_used;
	n_win_smallbutton_direct *smallbutton[ N_WIN_TXTBOX_SMALLBUTTON_MAX ];
	s32                       smallbutton_margin;
	UINT                      smallbutton_timer;

	n_posix_bool listbox_is_selected;
	n_posix_bool oneline_placeholder_onoff;

	n_posix_bool grayed_onoff;
	n_posix_bool is_grayed;

	n_posix_bool metrics_changed;


	// Optional

	n_posix_char *placeholder;
	n_posix_char *tab_mark;
	n_posix_char *eol_mark;

	s32           tabstop;

	n_posix_bool  mouse_input_stop_onoff;


	// Internal : auto-filled by the system

	HDC      hdc_printclient;
	POINT    ime;
	int      vk_mouse;
	int      vk_key;
	s32      scale;
	s32             hover_cch_x,  hover_cch_y ;
	s32             hover_under;
	s32             font_pxl_sx,   font_pxl_sy;
	s32                            cell_pxl_sy;
	s32            caret_pxl_x ,  caret_pxl_y ;
	s32            caret_pxl_sx,  caret_pxl_sy;
	s32           canvas_pxl_sx, canvas_pxl_sy;
	s32      canvas_real_pxl_sx;
	s32      page_pxl_tabbed_sx, page_cch_tabbed_sy;
	s32      last_pxl_tabbed_sx, last_cch_tabbed_sy;
	s32      virtual_padding_pxl_sx;
	s32      txt_maxwidth_y;

	n_posix_bool is_captured;
	n_posix_bool is_dragging;
	n_posix_bool is_caret_tail;
	n_posix_bool is_hovered_linenum;

	s32          empty_line_selection;

	n_posix_bool is_carrage_return;
	s32          carrage_return_cch_y;

	n_posix_bool is_backspace;
	s32          backspace_cch_y;

	int          is_lr;
	n_posix_bool is_ud;

	n_posix_bool is_font_monospace;
	SIZE         size_halfwidth;
	SIZE         size_fullwidth;

	s32          prv_scr_x,  prv_scr_y;
	s32          prv_sel_x,  prv_sel_y;
	s32          prv_sel_sx, prv_sel_sy;
	s32          prv_txt_sy;
	s32          prv_drag;
	s32          prv_caret_x, prv_caret_y;
	s32          prv_oneline_scroll;

	n_win_simplemenu menu_editbox;
	n_win_simplemenu menu_linenum;
	n_posix_bool     menu_onoff;
	int              menu_type;

	n_uxtheme    uxtheme;

	int          drag_phase;
	UINT         drag_timer;
	DWORD        drag_msec;
	s32          drag_cch_min;
	s32          drag_cch_max;
	s32          drag_cch_x;
	s32          drag_cch_y;
	POINT        drag_pt;

	n_posix_bool global_fade_onoff;

	n_posix_bool ime_onoff;
	n_posix_bool ime_composition_onoff;

	UINT         ime_fade_timer;
	n_bmp        ime_fade_bmp_old;
	n_bmp        ime_fade_bmp_new;
	n_posix_bool ime_fade_is_running;
	double       ime_fade_percent;

	UINT         focus_fade_timer;
	n_bmp        focus_fade_bmp_old;
	n_bmp        focus_fade_bmp_new;
	n_posix_bool focus_fade_override;
	n_posix_bool focus_fade_override_bool;
	s32          focus_fade_prv_sel_sx;
	double       focus_fade_percent;
	n_posix_bool focus_fade_is_running;

	UINT         caret_timer;
	double       caret_blend;
	n_posix_bool caret_fade_in;
	s32          caret_redraw_x;
	s32          caret_redraw_sx;
	n_posix_bool caret_blend_override_onoff;
	n_posix_bool caret_blend_override_value;

	n_posix_bool input_onoff;
	UINT         input_timer;
	DWORD        input_msec;

	double       text_fade_ratio;

	n_posix_bool bitblt_stop;

	n_posix_bool typing_only;

	int          shift_dragging;
	s32          shift_dragging_start_x;
	s32          shift_dragging_start_pxl_x;
	s32          shift_dragging_last_left;

	n_posix_bool optimization_click_onoff;

	n_posix_bool delayed_focus;

	n_posix_bool draw_frame_onoff;

	n_posix_bool selection_onoff;
	RECT         selection_rect;


	// Metrics : once per session

	n_posix_bool is_9x;
	n_posix_bool is_nt;
	n_posix_bool is_2k_or_later;
	n_posix_bool is_classic;
	s32         number_pxl_sx, number_pad_pxl_sx;
	s32         client_pxl_sx,     client_pxl_sy;
	s32         client_prv_sx,     client_prv_sy;
	s32         border_pxl_sx,     border_pxl_sy;
	s32            pad_pxl_sx,        pad_pxl_sy;
	s32      scrollbar_pxl_sx,  scrollbar_pxl_sy;
	COLORREF color_base__padding;
	COLORREF color_base_selected;
	COLORREF color_back_selected;
	COLORREF color_text_selected;
	COLORREF color_back_noselect;
	COLORREF color_text_noselect;
	COLORREF color_back_striping;
	COLORREF color_text_tab_mark;
	COLORREF color_text_eol_mark;
	COLORREF color_text_backgrnd;
	COLORREF color_back_linenum1;
	COLORREF color_back_linenum2;
	COLORREF color_back_linenum3;
	COLORREF color_text_linenum1;
	COLORREF color_text_linenum2;
	COLORREF color___placeholder;
	COLORREF color___dwm_contour;
	COLORREF color___dwm_textclr;
	COLORREF color___ime_watcher;
	COLORREF color_sel_focus__on;
	COLORREF color_sel_focus_off;
	COLORREF color_back_disabled;
	COLORREF color_back__enabled;
	COLORREF color_border_normal;
	COLORREF color_border__focus;
	COLORREF color_border___flat;
	UINT     drawtext_modes;


	// Debug Center

	n_posix_bool  optimization_onoff;
	n_posix_bool  optimization_stop;
	int           optimization_type;
	int           optimization_sync;

	n_posix_bool  debug_onoff;
	n_bmp        *debug_bmp;

	n_posix_bool  debug_draw_onoff;

} n_win_txtbox;

#define n_win_txtbox_zero( p ) n_memory_zero( p, sizeof( n_win_txtbox ) )


static n_posix_bool n_win_txtbox_printclient = n_posix_false;


