// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_PROGRESSBAR
#define _H_NONNON_WIN32_WIN_PROGRESSBAR




#include "../neutral/posix.c"


#include "./win/_debug.c"
#include "./win/message.c"
#include "./win/rect.c"




COLORREF
n_win_progressbar_textcolor( COLORREF color )
{

	// [!] : as monochrome

	int r = GetRValue( color );
	int g = GetGValue( color );
	int b = GetBValue( color );

	if ( 160 > ( ( r + g + b ) / 3 ) )
	{
		color = RGB( 255,255,255 );
	} else {
		color = RGB( 0,0,0 );
	}


	return color;
}

void
n_win_progressbar_text( HWND hgui, HDC hdc, RECT *rect, RECT *rect_bar, COLORREF color )
{

	const int dt = DT_CENTER | ( DT_SINGLELINE | DT_VCENTER ) | DT_NOPREFIX | DT_WORD_ELLIPSIS;


	n_win_box( hgui, hdc, rect_bar, color );


	{

		int           cch = n_win_text_len( hgui );
		n_posix_char *str = n_string_new( cch ); n_win_text_get( hgui, str, cch + 1 );

		SetBkMode   ( hdc, TRANSPARENT );
		SetTextColor( hdc, n_win_progressbar_textcolor( color ) );

		DrawText( hdc, str,cch, rect, dt );

		s32 ex,ey,esx,esy; n_win_rect_expand_range( rect_bar, &ex,&ey,&esx,&esy );
		ExcludeClipRect( hdc, ex,ey,esx,esy );

		n_string_free( str );

	}


	return;
}

void
n_win_progressbar_draw( HWND hgui, DRAWITEMSTRUCT *di, int edge, int percent, u32 bg, u32 fg )
{

	if ( di == NULL ) { return; }
	if ( hgui != di->hwndItem ) { return; }


	s32 x,y,sx,sy; n_win_rect_expand_size( &di->rcItem, &x, &y, &sx, &sy );


	HDC  hdc    = hdc = n_gdi_doublebuffer_simple_init( hgui, sx,sy );
	RECT rect   = di->rcItem;
	int  border = 2;


	if ( edge )
	{

		DrawEdge( hdc, &rect, edge, BF_RECT );

		n_win_rect_resize( &rect, -border,-border );

		n_win_rect_expand_size( &rect, &x, &y, &sx, &sy );

	}


	// [!] : "sx" will be reduced when "edge" is used

	s32 bar = (s32) trunc( percent * 0.01 * sx );

	if ( bar !=  0 )
	{
		RECT rect_l = n_win_rect_set( NULL, x, y, bar, sy );
		n_win_progressbar_text( hgui, hdc, &rect, &rect_l, fg );
	}

	if ( bar != sx )
	{
		RECT rect_r = n_win_rect_set( NULL, x + bar, y, sx - bar, sy );
		n_win_progressbar_text( hgui, hdc, &rect, &rect_r, bg );
	}


	if ( n_win_dwm_is_on() ) { n_gdi_doublebuffer_visible( &n_gdi_doublebuffer_instance ); }
	n_gdi_doublebuffer_simple_exit();



	return;
}

LRESULT CALLBACK
#ifdef _WIN64
n_win_progressbar_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
#else  // #ifdef _WIN64
n_win_progressbar_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
#endif // #ifdef _WIN64
{

#ifdef _WIN64
	//
#else  // #ifdef _WIN64
	const WNDPROC pfunc = (WNDPROC) n_win_property_get_literal( hwnd, "n_win_progressbar_subclass()" );
	if ( pfunc == NULL ) { return 0; }
#endif // #ifdef _WIN64


	switch( msg ) {


	case WM_ERASEBKGND :

		return TRUE;

	break;


	} // switch


#ifdef _WIN64
	return DefSubclassProc(        hwnd, msg, wparam, lparam );
#else  // #ifdef _WIN64
	return  CallWindowProc( pfunc, hwnd, msg, wparam, lparam );
#endif // #ifdef _WIN64
}

void
n_win_progressbar_proc
(
	HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam,
	HWND hgui,
	int  edge,
	int  percent,
	u32  fg,
	u32  bg
)
{

	// [ Mechansim ]
	//
	//	[ WM_CREATE ]
	//
	//	n_win_gui( hwnd, N_WIN_GUI_CANVAS, "", &hgui );
	//
	//	[ System Default ]
	//
	//	u32 fg = GetSysColor( COLOR_HIGHLIGHT );
	//	u32 bg = GetSysColor( COLOR_BTNFACE   );
	//
	//	[ border modes are not needed ]
	//
	//	+ WS_EX_CLIENTEDGE is not needed


	switch( msg ) {


	case WM_CREATE :

#ifdef _WIN64
		SetWindowSubclass( hgui, n_win_progressbar_subclass, 0, 0 );

#else  // #ifdef _WIN64

		n_win_property_init_literal
		(
			hgui,
			"n_win_progressbar_subclass()",
			(int) n_win_gui_subclass_set( hgui, n_win_progressbar_subclass )
		);

#endif // #ifdef _WIN64

	break;


	case WM_PAINT :

		n_win_refresh( hgui, n_posix_false );

	break;


	case WM_DRAWITEM :

		percent = n_posix_minmax( 0, 100, percent );

		n_win_progressbar_draw( hgui, (void*) lparam, edge, percent, bg, fg );

	break;


	} // switch


	return;
}


#endif // _H_NONNON_WIN32_WIN_PROGRESSBAR




/*
#include "./win.c"


LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	const int timer_id = 0;

	static HWND hgui[ 6 ];

	static int percent = 0;


	switch( msg ) {


	case WM_CREATE :


		// Global

		SetTimer( hwnd, timer_id, 33, NULL );


		// Window

		n_win_init_literal( hwnd, "Nonnon", "", "" );


		n_win_gui_literal( hwnd, N_WIN_GUI_CANVAS, "", &hgui[ 0 ] );


		// Style

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		// Size

		n_win_set( hwnd, NULL, 200,200, N_WIN_SET_CENTERING );


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_SIZE :
	{

		n_win w; n_win_set( hwnd, &w, -1,-1, N_WIN_SET_DEFAULT );

		s32 sx = w.csx;
		s32 sy = w.csy / 6;

		n_win_move( hgui[ 0 ], 0,sy*0, sx,sy, n_posix_true );

	}
	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 )
		{

			percent++;
			if ( percent > 100 )
			{
				percent = 0;
			}

			n_win_message_send( hgui[ 0 ], WM_PAINT, 0, 0 );

			n_win_hwndprintf( hgui[ 0 ], "%d", percent );

		}

	break;

	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_win_timer_exit( hwnd, timer_id );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	{
		u32 fg = GetSysColor( COLOR_HIGHLIGHT );
		u32 bg = GetSysColor( COLOR_BTNFACE   );
		n_win_progressbar_proc( hwnd,msg,wparam,lparam, hgui[ 0 ], EDGE_ETCHED, percent, fg,bg );
	}


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}


*/

